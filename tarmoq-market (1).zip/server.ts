import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // API router configuration
  app.get("/api/health", (req, res) => {
    res.json({ status: "active", uptime: process.uptime() });
  });

  app.get("/api/config", (req, res) => {
    res.json({
      googleEmail: "773649664s@gmail.com",
      version: "1.0.0",
      environment: process.env.NODE_ENV || "development"
    });
  });

  // Handle Vite asset loading during development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production serving static files of the built dist/ foldering index.html SPA
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Tarmoq Server] running on http://localhost:${PORT}`);
  });
}

startServer();
