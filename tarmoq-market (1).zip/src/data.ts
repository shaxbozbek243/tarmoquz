import { AppItem, User } from './types';

// Helper to generate custom icons dynamically
export const createSvgIcon = (name: string, bgColor: string, txtColor: string = '#ffffff') => {
  const shortName = name.substring(0, 2).toUpperCase();
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
    <rect width="100" height="100" rx="22" fill="${bgColor}" />
    <circle cx="50" cy="50" r="30" fill="none" stroke="${txtColor}" stroke-opacity="0.15" stroke-width="4"/>
    <text x="50" y="55" font-family="'Inter', sans-serif" font-weight="bold" font-size="34" fill="${txtColor}" text-anchor="middle" dominant-baseline="middle">${shortName}</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
};

export const createSvgScreenshot = (title: string, bgColor: string, txtColor: string = '#ffffff') => {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 200" width="320" height="200">
    <rect width="320" height="200" rx="12" fill="${bgColor}" />
    <rect x="20" y="20" width="280" height="160" rx="8" fill="#000000" fill-opacity="0.3" />
    <text x="50%" y="45%" font-family="'Inter', sans-serif" font-weight="bold" font-size="18" fill="${txtColor}" text-anchor="middle">${title}</text>
    <text x="50%" y="65%" font-family="'Inter', sans-serif" font-size="11" fill="${txtColor}" fill-opacity="0.7" text-anchor="middle">O'zbekistondagi eng ilg'or xizmat</text>
    <circle cx="50%" cy="85%" r="6" fill="${txtColor}" fill-opacity="0.9" />
    <circle cx="45%" cy="85%" r="4" fill="${txtColor}" fill-opacity="0.4" />
    <circle cx="55%" cy="85%" r="4" fill="${txtColor}" fill-opacity="0.4" />
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
};

export const INITIAL_USERS: User[] = [
  {
    id: 'admin_user',
    role: 'admin',
    email: 'admin@tarmoq.uz',
    password: 'admin',
    firstName: 'Tizim',
    lastName: 'Administratori',
    isBlocked: false,
    downloadedAppIds: []
  }
];

export const INITIAL_APPS: AppItem[] = [];

export const CATEGORIES = [
  'Barchasi',
  'Ilovalar',
  "O'yinlar",
  'Moliyaviy',
  'Ta\'lim',
  'Ko\'ngilochar'
];

