import { useState, useEffect } from 'react';
import { User, AppItem, ToastMessage, SystemMessage } from './types';
import { INITIAL_USERS, INITIAL_APPS } from './data';
import { ToastContainer } from './components/ToastContainer';
import { LandingView } from './components/LandingView';
import { AuthView } from './components/AuthView';
import { UserPanelView } from './components/UserPanelView';
import { CreatorPanelView } from './components/CreatorPanelView';
import { AdminPanelView } from './components/AdminPanelView';

export default function App() {
  // Main database storage states (In-memory reactive simulation)
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [apps, setApps] = useState<AppItem[]>(INITIAL_APPS);
  
  // App routing and sessions
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [view, setView] = useState<'landing' | 'auth' | 'user-panel' | 'creator-panel' | 'admin-panel'>('landing');
  const [selectedCategory, setSelectedCategory] = useState('Barchasi');

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // System announcements and direct messages
  const [systemMessages, setSystemMessages] = useState<SystemMessage[]>([
    {
      id: 'msg_1',
      sender: 'Administrator',
      recipientId: 'all',
      title: 'Xush kelibsiz!',
      content: 'Hurmatli foydalanuvchilar, Tarmoq Market o\'zbek ilovalar do\'koniga xush kelibsiz! Bu yerda eng sara o\'yin, to\'lov va ta\'lim ilovalarini xavfsiz yuklab olasiz.',
      date: '2026-06-11'
    }
  ]);

  // Global customizable beauty theme
  const [appAccentColor, setAppAccentColor] = useState<string>(() => {
    return localStorage.getItem('tarmoq_accent_color') || '#0a84ff';
  });
  const [appBgStyle, setAppBgStyle] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('tarmoq_bg_style') as 'dark' | 'light') || 'dark';
  });

  useEffect(() => {
    localStorage.setItem('tarmoq_accent_color', appAccentColor);
    localStorage.setItem('tarmoq_bg_style', appBgStyle);
    
    // Dynamically inject custom stylesheets/overrides into document.head to target `#0a84ff` globally
    let styleTag = document.getElementById('tarmoq-dynamic-theme-style');
    if (!styleTag) {
      styleTag = document.createElement('style');
      styleTag.id = 'tarmoq-dynamic-theme-style';
      document.head.appendChild(styleTag);
    }
    
    styleTag.textContent = `
      :root {
        --app-accent: ${appAccentColor};
        --app-bg: ${appBgStyle === 'dark' ? '#0f0f0f' : '#f9fafb'};
        --app-card-bg: ${appBgStyle === 'dark' ? '#1c1c1e' : '#ffffff'};
        --app-border: ${appBgStyle === 'dark' ? '#2c2c2e' : '#e5e7eb'};
        --app-text: ${appBgStyle === 'dark' ? '#e5e7eb' : '#1f2937'};
        --app-text-strong: ${appBgStyle === 'dark' ? '#ffffff' : '#111827'};
      }
      
      .tarmoq-dynamic-bg {
        background-color: var(--app-bg) !important;
      }
      .tarmoq-dynamic-card {
        background-color: var(--app-card-bg) !important;
        border-color: var(--app-border) !important;
      }
      .tarmoq-dynamic-border {
        border-color: var(--app-border) !important;
      }
      .tarmoq-dynamic-text {
        color: var(--app-text) !important;
      }
      .tarmoq-dynamic-text-strong {
        color: var(--app-text-strong) !important;
      }
      
      /* Accent style overrides */
      .accent-bg {
        background-color: var(--app-accent) !important;
      }
      .accent-gradient-bg {
        background: linear-gradient(135deg, var(--app-accent) 0%, #111111 100%) !important;
      }
      .accent-text {
        color: var(--app-accent) !important;
      }
      .accent-border {
        border-color: var(--app-accent) !important;
      }
      .accent-ring {
        box-shadow: 0 0 0 2px var(--app-accent) !important;
      }
      
      /* Overwrite exact Tailwind v4 compiled class tokens dynamically */
      .bg-\\[\\#0a84ff\\] {
        background-color: var(--app-accent) !important;
      }
      .text-\\[\\#0a84ff\\] {
        color: var(--app-accent) !important;
      }
      .border-\\[\\#0a84ff\\] {
        border-color: var(--app-accent) !important;
      }
      .focus\\:border-\\[\\#0a84ff\\]:focus {
        border-color: var(--app-accent) !important;
      }
      .border-l-\\[\\#0a84ff\\] {
        border-left-color: var(--app-accent) !important;
      }
      .from-\\[\\#0a84ff\\] {
        --tw-gradient-from: var(--app-accent) !important;
        --tw-gradient-to: rgba(10, 132, 255, 0) !important;
        --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to) !important;
      }
    `;
  }, [appAccentColor, appBgStyle]);

  const onAdminUpdateUserPassword = (userId: string, newPass: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, password: newPass } : u))
    );
    // Sync active session if the admin changes their own or current active user profile password
    if (currentUser && currentUser.id === userId) {
      setCurrentUser((prev) => (prev ? { ...prev, password: newPass } : null));
    }
    showToast("Parol muvaffaqiyatli o'zgartirildi!", "success");
  };

  const onAdminUpdateAppFields = (appId: string, updatedFields: Partial<AppItem>) => {
    setApps((prev) =>
      prev.map((a) => (a.id === appId ? { ...a, ...updatedFields } : a))
    );
    showToast("Ilova parametrlari muvaffaqiyatli saqlandi!", "success");
  };

  const onAdminSendMessage = (title: string, content: string, recipientId: string) => {
    const newMessage: SystemMessage = {
      id: `msg_${Date.now()}`,
      sender: 'Administrator',
      recipientId,
      title,
      content,
      date: new Date().toISOString().split('T')[0]
    };
    setSystemMessages((prev) => [newMessage, ...prev]);
    showToast("Xabaringiz muvaffaqiyatli yetkazildi!", "success");
  };

  // Monitor location hash to support admin auth transition immediately
  useEffect(() => {
    const handleHashCheck = () => {
      if (window.location.hash === '#admin') {
        setView('auth');
      }
    };
    handleHashCheck();
    window.addEventListener('hashchange', handleHashCheck);
    return () => window.removeEventListener('hashchange', handleHashCheck);
  }, []);

  const showToast = (text: string, type: 'success' | 'error' | 'info') => {
    const newToast: ToastMessage = {
      id: `toast_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      text,
      type
    };
    setToasts((prev) => [...prev, newToast]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // SUCCESS ACTIONS
  const onAddUser = (newUser: User) => {
    setUsers((prev) => [...prev, newUser]);
  };

  const onLoginSuccess = (user: User) => {
    setCurrentUser(user);
    if (user.role === 'user') {
      setView('user-panel');
    } else if (user.role === 'creator') {
      setView('creator-panel');
    } else if (user.role === 'admin') {
      setView('admin-panel');
    }
  };

  const onLogout = () => {
    setCurrentUser(null);
    setView('landing');
    setSelectedCategory('Barchasi');
    // Clear URL hash safely
    if (window.location.hash) {
      window.history.pushState('', document.title, window.location.pathname + window.location.search);
    }
    showToast("Tizimdan muvaffaqiyatli chiqdingiz. Salomat bo'ling!", "info");
  };

  // CLIENT PANEL DIRECTIVES
  const onDownloadApp = (appId: string) => {
    if (!currentUser) return;

    // Find custom app details list to read app name and custom apk filename
    const targetApp = apps.find((a) => a.id === appId);
    if (targetApp) {
      try {
        const rawApkName = targetApp.apkFileName || `${targetApp.name.toLowerCase().replace(/\s+/g, '_')}.apk`;
        const apkName = rawApkName.endsWith('.apk') ? rawApkName : `${rawApkName}.apk`;
        
        // Construct physical blob to trigger browser download
        const blob = new Blob([`// Tarmoq Store App Package\n// Name: ${targetApp.name}\n// Version: ${targetApp.version}\n// Size: ${targetApp.fileSize}`], { type: "application/vnd.android.package-archive" });
        const downloadUrl = URL.createObjectURL(blob);
        const downloadAnchor = document.createElement("a");
        downloadAnchor.href = downloadUrl;
        downloadAnchor.download = apkName;
        document.body.appendChild(downloadAnchor);
        downloadAnchor.click();
        document.body.removeChild(downloadAnchor);
        URL.revokeObjectURL(downloadUrl);
        
        showToast(`"${apkName}" yuklab olish muvaffaqiyatli boshlandi!`, "success");
      } catch (err) {
        console.error("Download failed:", err);
      }
    }

    // 1. Mark app as downloaded in User object
    const alreadyDownloaded = currentUser.downloadedAppIds.includes(appId);
    
    setUsers((prevUsers) =>
      prevUsers.map((u) => {
        if (u.id === currentUser.id) {
          const updatedIds = alreadyDownloaded
            ? u.downloadedAppIds
            : [...u.downloadedAppIds, appId];
          return { ...u, downloadedAppIds: updatedIds };
        }
        return u;
      })
    );

    // Update session user to remain in sync
    setCurrentUser((prev) => {
      if (!prev) return null;
      const updatedIds = alreadyDownloaded
        ? prev.downloadedAppIds
        : [...prev.downloadedAppIds, appId];
      return { ...prev, downloadedAppIds: updatedIds };
    });

    // 2. Increment download score in app
    setApps((prevApps) =>
      prevApps.map((a) => {
        if (a.id === appId) {
          return { ...a, downloadsCount: a.downloadsCount + 1 };
        }
        return a;
      })
    );

    showToast("Yuklash boshlandi! Ilova muvaffaqiyatli qurilmangizga o'rnatildi.", "success");
  };

  const onAddReview = (appId: string, rating: number, text: string) => {
    if (!currentUser) return;

    // Get Today's date (formatted simple)
    const today = new Date();
    const dateStr = today.toISOString().split('T')[0];

    const newReview = {
      id: `rev_${Date.now()}`,
      appId,
      userName: `${currentUser.firstName || 'Foydalanuvchi'} ${currentUser.lastName || ''}`.trim(),
      rating,
      text,
      date: dateStr
    };

    setApps((prevApps) =>
      prevApps.map((a) => {
        if (a.id === appId) {
          const updatedReviews = [newReview, ...a.reviews];
          return {
            ...a,
            reviews: updatedReviews,
            ratingsCount: a.ratingsCount + 1,
            ratingsSum: a.ratingsSum + rating
          };
        }
        return a;
      })
    );

    showToast("Fikr-mulohazangiz qabul qilindi! Samimiy sharhingiz uchun tashakkur.", "success");
  };

  const onUpdateUserProfile = (firstName: string, lastName: string, password?: string) => {
    if (!currentUser) return;

    setUsers((prevUsers) =>
      prevUsers.map((u) => {
        if (u.id === currentUser.id) {
          const updated = { ...u, firstName, lastName };
          if (password) updated.password = password;
          return updated;
        }
        return u;
      })
    );

    setCurrentUser((prev) => {
      if (!prev) return null;
      const updated = { ...prev, firstName, lastName };
      if (password) updated.password = password;
      return updated;
    });

    showToast("Profil ma'lumotlari muvaffaqiyatli yangilandi", "success");
  };

  // CREATOR PANEL DIRECTIVES
  const onAddApp = (newApp: Omit<AppItem, 'id' | 'creatorId' | 'developer' | 'downloadsCount' | 'ratingsCount' | 'ratingsSum' | 'isTop' | 'reviews'>) => {
    if (!currentUser) return;

    const fullAppItem: AppItem = {
      ...newApp,
      id: `app_${Date.now()}`,
      creatorId: currentUser.id,
      developer: currentUser.companyName || `${currentUser.firstName} ${currentUser.lastName}`.trim(),
      downloadsCount: 0,
      ratingsCount: 0,
      ratingsSum: 0,
      isTop: false,
      reviews: []
    };

    setApps((prev) => [...prev, fullAppItem]);
  };

  const onDeleteApp = (appId: string) => {
    setApps((prev) => prev.filter((a) => a.id !== appId));
    showToast("Ilova platformadan butunlay o'chirildi", "info");
  };

  const onUpdateCreatorProfile = (
    companyName: string,
    firstName: string,
    bio: string,
    companyLogo?: string,
    password?: string
  ) => {
    if (!currentUser) return;

    setUsers((prevUsers) =>
      prevUsers.map((u) => {
        if (u.id === currentUser.id) {
          const updated = { ...u, companyName, firstName, bio, companyLogo };
          if (password) updated.password = password;
          return updated;
        }
        return u;
      })
    );

    setCurrentUser((prev) => {
      if (!prev) return null;
      const updated = { ...prev, companyName, firstName, bio, companyLogo };
      if (password) updated.password = password;
      return updated;
    });
  };

  // ADMIN PANEL DIRECTIVES
  const onApproveApp = (appId: string) => {
    setApps((prev) =>
      prev.map((a) => {
        if (a.id === appId) {
          return { ...a, status: 'approved' };
        }
        return a;
      })
    );
  };

  const onRejectApp = (appId: string) => {
    setApps((prev) =>
      prev.map((a) => {
        if (a.id === appId) {
          return { ...a, status: 'rejected' };
        }
        return a;
      })
    );
  };

  const onToggleTopApp = (appId: string) => {
    setApps((prev) =>
      prev.map((a) => {
        if (a.id === appId) {
          return { ...a, isTop: !a.isTop };
        }
        return a;
      })
    );
  };

  const onToggleBlockUser = (userId: string) => {
    setUsers((prevUsers) =>
      prevUsers.map((u) => {
        if (u.id === userId) {
          return { ...u, isBlocked: !u.isBlocked };
        }
        return u;
      })
    );
    // If the blocked user matches session, force signout immediately
    if (currentUser && currentUser.id === userId) {
      onLogout();
    }
  };

  const onDeleteUser = (userId: string) => {
    setUsers((prev) => prev.filter((u) => u.id !== userId));
    // If deleted user is logged in
    if (currentUser && currentUser.id === userId) {
      onLogout();
    }
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-gray-200 selection:bg-[#0a84ff]/30 selection:text-white" id="main-application-frame">
      
      {/* 1. View Router */}
      {view === 'landing' && (
        <LandingView
          apps={apps}
          onNavigateToAuth={() => setView('auth')}
          onSelectCategory={(category) => setSelectedCategory(category)}
          selectedCategory={selectedCategory}
        />
      )}

      {view === 'auth' && (
        <AuthView
          onSuccess={onLoginSuccess}
          onNavigateBack={() => {
            setView('landing');
            if (window.location.hash) {
              window.history.pushState('', document.title, window.location.pathname + window.location.search);
            }
          }}
          users={users}
          onAddUser={onAddUser}
          showToast={showToast}
        />
      )}

      {view === 'user-panel' && currentUser && (
        <UserPanelView
          currentUser={currentUser}
          onLogout={onLogout}
          apps={apps}
          onDownloadApp={onDownloadApp}
          onAddReview={onAddReview}
          onUpdateUserProfile={onUpdateUserProfile}
          showToast={showToast}
          systemMessages={systemMessages}
        />
      )}

      {view === 'creator-panel' && currentUser && (
        <CreatorPanelView
          currentUser={currentUser}
          onLogout={onLogout}
          apps={apps}
          onAddApp={onAddApp}
          onDeleteApp={onDeleteApp}
          onUpdateCreatorProfile={onUpdateCreatorProfile}
          onUpdateAppFields={onAdminUpdateAppFields}
          showToast={showToast}
        />
      )}

      {view === 'admin-panel' && currentUser && (
        <AdminPanelView
          currentUser={currentUser}
          onLogout={onLogout}
          apps={apps}
          users={users}
          onApproveApp={onApproveApp}
          onRejectApp={onRejectApp}
          onToggleTopApp={onToggleTopApp}
          onDeleteApp={onDeleteApp}
          onToggleBlockUser={onToggleBlockUser}
          onDeleteUser={onDeleteUser}
          showToast={showToast}
          systemMessages={systemMessages}
          onAdminUpdateUserPassword={onAdminUpdateUserPassword}
          onAdminUpdateAppFields={onAdminUpdateAppFields}
          onAdminSendMessage={onAdminSendMessage}
          appAccentColor={appAccentColor}
          onUpdateAppAccentColor={setAppAccentColor}
          appBgStyle={appBgStyle}
          onUpdateAppBgStyle={setAppBgStyle}
        />
      )}

      {/* 2. Global Toast overlay */}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
      
    </div>
  );
}
