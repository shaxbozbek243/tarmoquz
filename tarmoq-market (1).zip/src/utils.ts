import { AppItem } from './types';

// Yuklamalar formati: 1234 -> "1.2K", 1200000 -> "1.2M"
export const formatDownloads = (num: number): string => {
  if (num >= 1000000) {
    const formatted = (num / 1000000).toFixed(1);
    return formatted.replace(/\.0$/, '') + 'M';
  }
  if (num >= 1000) {
    const formatted = (num / 1000).toFixed(1);
    return formatted.replace(/\.0$/, '') + 'K';
  }
  return num.toString();
};

export const getAverageRating = (app: AppItem): number => {
  if (app.ratingsCount === 0) return 0;
  return Math.round((app.ratingsSum / app.ratingsCount) * 10) / 10;
};

// Convert uploaded media to Base64 preview
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });
};
