export type UserRole = 'user' | 'creator' | 'admin';

export interface Review {
  id: string;
  appId: string;
  userName: string;
  rating: number; // 1-5
  text: string;
  date: string;
}

export interface AppItem {
  id: string;
  name: string;
  shortDescription: string;
  description: string;
  category: string; // e.g. "Ilovalar" | "O'yinlar" | "Ijtimoiy" | "Moliyaviy" | "Sayohat"
  version: string;
  platform: string;
  fileSize: string;
  apkFileName?: string; // Simulated APK file name
  icon: string; // Base64 or image url
  screenshots: string[]; // Base64 arrays
  developer: string; // Ism-familiya or Kompaniya nomi
  creatorId: string;
  status: 'pending' | 'approved' | 'rejected';
  downloadsCount: number;
  ratingsCount: number;
  ratingsSum: number;
  isTop: boolean; // Approved + Admin selected for "Tavsiya etilgan" top banner
  reviews: Review[];
}

export interface User {
  id: string;
  role: UserRole;
  email: string;
  password?: string;
  firstName?: string;
  lastName?: string;
  companyName?: string;
  companyLogo?: string;
  bio?: string;
  isBlocked: boolean;
  downloadedAppIds: string[]; // Track which apps this user has downloaded
}

export interface SystemMessage {
  id: string;
  sender: string;
  recipientId: 'all' | string; // 'all' or specific userId
  title: string;
  content: string;
  date: string;
}

export interface ToastMessage {
  id: string;
  text: string;
  type: 'success' | 'error' | 'info';
}
