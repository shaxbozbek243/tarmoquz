import React, { useState } from 'react';
import { AppItem, User, SystemMessage } from '../types';
import { formatDownloads, getAverageRating } from '../utils';
import { 
  ShoppingBag, LogOut, LayoutDashboard, Folder, Users, Star, 
  ShieldAlert, Check, X, Shield, Lock, Trash2, Settings, Palette,
  Send, Bell 
} from 'lucide-react';

interface AdminPanelViewProps {
  currentUser: User;
  onLogout: () => void;
  apps: AppItem[];
  users: User[];
  onApproveApp: (appId: string) => void;
  onRejectApp: (appId: string) => void;
  onToggleTopApp: (appId: string) => void;
  onDeleteApp: (appId: string) => void;
  onToggleBlockUser: (userId: string) => void;
  onDeleteUser: (userId: string) => void;
  showToast: (text: string, type: 'success' | 'error' | 'info') => void;
  systemMessages: SystemMessage[];
  onAdminUpdateUserPassword: (userId: string, newPass: string) => void;
  onAdminUpdateAppFields: (appId: string, updatedFields: Partial<AppItem>) => void;
  onAdminSendMessage: (title: string, content: string, recipientId: string) => void;
  
  // Custom theme controls set by Admin
  appAccentColor: string;
  onUpdateAppAccentColor: (color: string) => void;
  appBgStyle: 'dark' | 'light';
  onUpdateAppBgStyle: (style: 'dark' | 'light') => void;
}

export const AdminPanelView: React.FC<AdminPanelViewProps> = ({
  currentUser,
  onLogout,
  apps,
  users,
  onApproveApp,
  onRejectApp,
  onToggleTopApp,
  onDeleteApp,
  onToggleBlockUser,
  onDeleteUser,
  showToast,
  systemMessages,
  onAdminUpdateUserPassword,
  onAdminUpdateAppFields,
  onAdminSendMessage,
  appAccentColor,
  onUpdateAppAccentColor,
  appBgStyle,
  onUpdateAppBgStyle
}) => {
  const [activeTab, setActiveTab] = useState<'umumiy' | 'ilovalar' | 'foydalanuvchilar' | 'xabarlar-yuborish' | 'dizayn-sozlamalari'>('umumiy');
  
  // Search state variables
  const [userSearchText, setUserSearchText] = useState('');
  const [appSearchText, setAppSearchText] = useState('');

  // Password editing state
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [newPasswordVal, setNewPasswordVal] = useState('');

  // App editing states
  const [editingAppId, setEditingAppId] = useState<string | null>(null);
  const [editAppName, setEditAppName] = useState('');
  const [editAppCategory, setEditAppCategory] = useState('');
  const [editAppShortDesc, setEditAppShortDesc] = useState('');
  const [editAppLongDesc, setEditAppLongDesc] = useState('');
  const [editAppVersion, setEditAppVersion] = useState('');
  const [editAppSize, setEditAppSize] = useState('');
  const [editAppPlatform, setEditAppPlatform] = useState('');
  const [editAppDownloads, setEditAppDownloads] = useState(0);

  // Message compose states
  const [msgRecipient, setMsgRecipient] = useState('all');
  const [msgTitle, setMsgTitle] = useState('');
  const [msgContent, setMsgContent] = useState('');

  // Color selection state
  const [customColorInput, setCustomColorInput] = useState(appAccentColor);

  // Stats calculation
  const totalApps = apps.length;
  const pendingApps = apps.filter(a => a.status === 'pending');
  const approvedApps = apps.filter(a => a.status === 'approved');
  const totalDownloads = apps.reduce((sum, app) => sum + app.downloadsCount, 0);

  const presets = [
    { name: "Uzbek Emerald Green (Yashil)", hex: "#2e7d32" },
    { name: "Google Play Royal Blue (Ko'k)", hex: "#0a84ff" },
    { name: "iOS Crimson (Qizil)", hex: "#ff3b30" },
    { name: "Gold Violet (Siyohrang)", hex: "#8e44ad" },
    { name: "High-contrast Slate (Qora)", hex: "#222222" },
    { name: "Flame Orange (Olovrang)", hex: "#e67e22" }
  ];

  // Quick Action triggers
  const handleApprove = (id: string, name: string) => {
    onApproveApp(id);
    showToast(`"${name}" ilovasi muvaffaqiyatli tasdiqlandi!`, "success");
  };

  const handleReject = (id: string, name: string) => {
    const isConfirmed = window.confirm(`"${name}" ilovasini rad etishingizni tasdiqlaysizmi?`);
    if (isConfirmed) {
      onRejectApp(id);
      showToast(`"${name}" ilovasi rad etildi`, "info");
    }
  };

  const handleToggleBlock = (userId: string, name: string, isBlocked: boolean) => {
    const isConfirmed = window.confirm(`Haqiqatan ham "${name}" foydalanuvchisini ${isBlocked ? "blokdan chiqarmoqchimisiz?" : "bloklamoqchimisiz?"}`);
    if (isConfirmed) {
      onToggleBlockUser(userId);
      showToast(`Foydalanuvchi ${isBlocked ? 'blokdan ochildi' : 'bloklandi'}!`, "info");
    }
  };

  const handleDeleteUser = (userId: string, name: string) => {
    const isConfirmed = window.confirm(`Haqiqatan ham "${name}" hisobini butunlay o'chirib tashlamoqchimisiz?`);
    if (isConfirmed) {
      onDeleteUser(userId);
      showToast("Hisob o'chirib yuborildi", "success");
    }
  };

  const handleDeleteApp = (appId: string, name: string) => {
    const isConfirmed = window.confirm(`Haqiqatan ham "${name}" ilovasini o'chirmoqchimisiz?`);
    if (isConfirmed) {
      onDeleteApp(appId);
      showToast("Ilova do'kondan o'chirildi", "success");
    }
  };

  const saveNewUserPassword = (userId: string) => {
    if (!newPasswordVal.trim()) {
      showToast("Parol kiritilmadi!", "error");
      return;
    }
    onAdminUpdateUserPassword(userId, newPasswordVal.trim());
    setEditingUserId(null);
    setNewPasswordVal('');
  };

  const openAppEditorForm = (app: AppItem) => {
    setEditingAppId(app.id);
    setEditAppName(app.name);
    setEditAppCategory(app.category);
    setEditAppShortDesc(app.shortDescription);
    setEditAppLongDesc(app.description);
    setEditAppVersion(app.version);
    setEditAppSize(app.fileSize);
    setEditAppPlatform(app.platform);
    setEditAppDownloads(app.downloadsCount);
  };

  const saveAppEdits = () => {
    if (!editingAppId) return;
    if (!editAppName.trim() || !editAppShortDesc.trim() || !editAppVersion.trim() || !editAppSize.trim()) {
      showToast("Iltimos, asosiy maydonlarni bo'sh qoldirmang!", "error");
      return;
    }

    onAdminUpdateAppFields(editingAppId, {
      name: editAppName.trim(),
      category: editAppCategory,
      shortDescription: editAppShortDesc.trim(),
      description: editAppLongDesc.trim(),
      version: editAppVersion.trim(),
      fileSize: editAppSize.trim(),
      platform: editAppPlatform,
      downloadsCount: Number(editAppDownloads) || 0
    });

    showToast("Ilova muvaffaqiyatli tahrirlandi!", "success");
    setEditingAppId(null);
  };

  const handleSendMessageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgTitle.trim() || !msgContent.trim()) {
      showToast("Mavzu va matnni to'liq to'ldiring!", "error");
      return;
    }
    onAdminSendMessage(msgTitle.trim(), msgContent.trim(), msgRecipient);
    setMsgTitle('');
    setMsgContent('');
    showToast("Xabar muvaffaqiyatli jo'natildi!", "success");
  };

  const handleSaveThemeSettings = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^#[0-9A-F]{6}$/i.test(customColorInput)) {
      showToast("Iltimos, Hex rang kodini to'g'ri kiriting! (Masalan: #2e7d32)", "error");
      return;
    }
    onUpdateAppAccentColor(customColorInput);
    showToast(`Tizim rangi muvaffaqiyatli o'zgartirildi: ${customColorInput}`, "success");
  };

  // Filtered lists
  const filteredUsers = users.filter(u => {
    const query = userSearchText.toLowerCase();
    return (
      u.id.toLowerCase().includes(query) ||
      (u.firstName || '').toLowerCase().includes(query) ||
      (u.lastName || '').toLowerCase().includes(query) ||
      u.email.toLowerCase().includes(query)
    );
  });

  const filteredApps = apps.filter(a => {
    const query = appSearchText.toLowerCase();
    return (
      a.id.toLowerCase().includes(query) ||
      a.name.toLowerCase().includes(query) ||
      a.developer.toLowerCase().includes(query) ||
      a.category.toLowerCase().includes(query)
    );
  });

  return (
    <div className="min-h-screen bg-black text-white font-sans flex flex-col" id="admin-workspace-grayscale">
      
      {/* MONOCHROME COMPACT HEADER NAVBAR (No Default credentials shown, fully secret!) */}
      <nav className="bg-black border-b border-zinc-800 sticky top-0 z-40 px-4 py-4 md:px-8 flex items-center justify-between" id="admin-nav">
        <div className="flex items-center gap-2.5">
          <div className="p-2 border border-white rounded-lg flex items-center justify-center text-white bg-black">
            <Shield size={18} />
          </div>
          <div>
            <h1 className="text-sm font-black tracking-widest text-white uppercase">
              TARMOQ APP CONTROLLER
            </h1>
            <p className="text-[9px] text-zinc-500 font-mono tracking-widest uppercase">
              Boshqaruv Tizimi
            </p>
          </div>
        </div>

        <div className="flex items-center gap-5">
          <div className="hidden md:block text-right">
            <p className="text-xs font-black text-white uppercase tracking-wider font-mono">Xavfsiz Kirish Tizimi</p>
            <p className="text-[9px] text-zinc-500 uppercase tracking-widest font-mono">Ruxsat darajasi: Root Admin</p>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-950 hover:bg-zinc-900 border border-zinc-800 text-stone-300 font-bold text-xs rounded-lg cursor-pointer transition-colors"
          >
            <LogOut size={12} />
            <span>Chiqish</span>
          </button>
        </div>
      </nav>

      {/* MONOCHROME SUB-NAV TABS */}
      <div className="bg-black border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-start gap-1 overflow-x-auto scrollbar-none">
          {[
            { id: 'umumiy', label: 'Umumiy & Arizalar', icon: <LayoutDashboard size={13} /> },
            { id: 'ilovalar', label: `Ilovalar (${apps.length})`, icon: <Folder size={13} /> },
            { id: 'foydalanuvchilar', label: `A'zolar (${users.length})`, icon: <Users size={13} /> },
            { id: 'xabarlar-yuborish', label: 'Xabarlar Yo\'llash', icon: <Bell size={13} /> },
            { id: 'dizayn-sozlamalari', label: 'Tizim Dizayni & Ranglari', icon: <Palette size={13} /> }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-3.5 px-4 font-bold text-xs tracking-tight border-b-2 whitespace-nowrap cursor-pointer flex items-center gap-1.5 transition-colors ${
                activeTab === tab.id
                  ? 'border-white text-white bg-zinc-900/50'
                  : 'border-transparent text-zinc-500 hover:text-white'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* MAIN CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-8 py-6 space-y-6">
        
        {/* =======================================================
            TAB: UMUMIY
            ======================================================= */}
        {activeTab === 'umumiy' && (
          <div className="space-y-6" id="tab-umumiy-grayscale">
            
            {/* Minimal Stat Panel */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-black border border-zinc-800 p-5 rounded-xl">
                <span className="text-[10px] text-zinc-500 font-extrabold block uppercase tracking-wider">Arizalar (Kutilmoqda)</span>
                <span className="text-xl font-black text-white mt-1 block">{pendingApps.length} ta ilova</span>
              </div>
              <div className="bg-black border border-zinc-800 p-5 rounded-xl">
                <span className="text-[10px] text-zinc-500 font-extrabold block uppercase tracking-wider">Hisoblar Umumiy</span>
                <span className="text-xl font-black text-white mt-1 block">{users.length} ta foydalanuvchi</span>
              </div>
              <div className="bg-black border border-zinc-800 p-5 rounded-xl">
                <span className="text-[10px] text-zinc-500 font-extrabold block uppercase tracking-wider">Tasdiqlangan Ilovalar</span>
                <span className="text-xl font-black text-white mt-1 block">{approvedApps.length} ta ilova</span>
              </div>
              <div className="bg-black border border-zinc-800 p-5 rounded-xl">
                <span className="text-[10px] text-zinc-500 font-extrabold block uppercase tracking-wider">Umumiy O'rnatishlar</span>
                <span className="text-xl font-black text-white mt-1 block">{formatDownloads(totalDownloads)} ta</span>
              </div>
            </div>

            {/* Application Approval Flow Widget */}
            <div className="bg-black border border-zinc-800 rounded-xl p-5 space-y-4">
              <h2 className="text-xs uppercase font-black tracking-widest text-white flex items-center gap-2 border-b border-zinc-850 pb-2">
                <ShieldAlert size={14} />
                <span>Navbatdagi arizalar va ilovalar paketlari</span>
              </h2>

              {pendingApps.length === 0 ? (
                <p className="text-xs text-zinc-500 py-8 text-center bg-zinc-950/20 rounded-lg">Yangi yuklangan arizalar navbati bo'sh.</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {pendingApps.map(app => (
                    <div key={app.id} className="bg-zinc-950 border border-zinc-850 p-4 rounded-xl flex flex-col justify-between">
                      <div>
                        <div className="flex items-center gap-3">
                          <img src={app.icon} alt={app.name} className="w-10 h-10 rounded-lg object-cover border border-zinc-800" />
                          <div>
                            <span className="text-[9px] text-zinc-400 font-mono">ID: {app.id} | {app.category}</span>
                            <h4 className="text-sm font-bold text-white">{app.name}</h4>
                            <p className="text-xs text-zinc-500">Dasturchi/Kompaniya: {app.developer}</p>
                          </div>
                        </div>

                        <div className="bg-black p-3 rounded-lg text-xs space-y-1 mt-3 border border-zinc-900">
                          <p className="text-zinc-400 italic">"{app.shortDescription}"</p>
                          <div className="flex gap-4 pt-1.5 border-t border-zinc-900 text-[10px] text-zinc-600 font-mono">
                            <span>V: {app.version}</span>
                            <span>Hajmi: {app.fileSize}</span>
                            <span>Platforma: {app.platform}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-2 pt-4">
                        <button
                          type="button"
                          onClick={() => handleReject(app.id, app.name)}
                          className="flex-1 py-1.5 bg-black hover:bg-zinc-900 text-zinc-400 border border-zinc-800 text-xs font-bold rounded-lg cursor-pointer"
                        >
                          Rad etish
                        </button>
                        <button
                          type="button"
                          onClick={() => handleApprove(app.id, app.name)}
                          className="flex-1 py-1.5 bg-white hover:bg-zinc-150 text-black text-xs font-bold rounded-lg cursor-pointer"
                        >
                          Tasdiqlash (Do'konga chiqarish)
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-xl">
              <p className="text-xs text-zinc-400 leading-relaxed">
                ℹ️ <strong>Admin eslatmasi:</strong> Barcha yuklangan APK fayllarning xavfsizligi, mb hisoblari va do'kon faoliyati bevosita nazoratingiz ostidadir.
              </p>
            </div>
          </div>
        )}

        {/* =======================================================
            TAB: ILOVALAR
            ======================================================= */}
        {activeTab === 'ilovalar' && (
          <div className="space-y-4" id="tab-ilovalar-grayscale">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-black uppercase text-white tracking-widest">Do'kondagi dasturlar jadvali</h3>
                <p className="text-xs text-zinc-500">Dasturlarni to'liq boshqarish: tahrirlash, o'chirish, va TOP ro'yxatiga fiksatsiya qilish.</p>
              </div>
              <input
                type="text"
                value={appSearchText}
                onChange={e => setAppSearchText(e.target.value)}
                placeholder="Qidiruv..."
                className="bg-black text-white border border-zinc-850 rounded px-3 py-1.5 text-xs w-full md:w-64 focus:outline-none focus:border-white"
              />
            </div>

            {/* App Editor Inline Drawer Banner */}
            {editingAppId && (
              <form onSubmit={(e) => { e.preventDefault(); saveAppEdits(); }} className="bg-zinc-950 border border-white rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-zinc-850 pb-2">
                  <span className="text-[10px] font-black text-white uppercase font-mono">Tahrirlash: {editAppName}</span>
                  <button type="button" onClick={() => setEditingAppId(null)} className="text-zinc-500 hover:text-white text-xs">✕</button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  <div>
                    <label className="block text-[10px] text-zinc-500 uppercase font-bold mb-1">Dastur nomi</label>
                    <input
                      type="text"
                      value={editAppName}
                      required
                      onChange={e => setEditAppName(e.target.value)}
                      className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-zinc-500 uppercase font-bold mb-1">Kategoriya</label>
                    <select
                      value={editAppCategory}
                      onChange={e => setEditAppCategory(e.target.value)}
                      className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-white"
                    >
                      <option value="Ilovalar">Ilovalar</option>
                      <option value="O'yinlar">O'yinlar</option>
                      <option value="Moliyaviy">Moliyaviy</option>
                      <option value="Ta'lim">Ta'lim</option>
                      <option value="Ko'ngilochar">Ko'ngilochar</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] text-zinc-500 uppercase font-bold mb-1">Platforma</label>
                    <input
                      type="text"
                      value={editAppPlatform}
                      required
                      onChange={e => setEditAppPlatform(e.target.value)}
                      className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-zinc-500 uppercase font-bold mb-1">Versiyasi</label>
                    <input
                      type="text"
                      value={editAppVersion}
                      required
                      onChange={e => setEditAppVersion(e.target.value)}
                      className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-zinc-500 uppercase font-bold mb-1">Dastur hajmi (MB)</label>
                    <input
                      type="text"
                      value={editAppSize}
                      required
                      onChange={e => setEditAppSize(e.target.value)}
                      className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-zinc-500 uppercase font-bold mb-1">Yuklanish soni</label>
                    <input
                      type="number"
                      value={editAppDownloads}
                      required
                      onChange={e => setEditAppDownloads(Number(e.target.value))}
                      className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-white font-mono"
                    />
                  </div>
                  <div className="md:col-span-3">
                    <label className="block text-[10px] text-zinc-500 uppercase font-bold mb-1">Qisqacha tavsif</label>
                    <input
                      type="text"
                      value={editAppShortDesc}
                      required
                      onChange={e => setEditAppShortDesc(e.target.value)}
                      className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-white"
                    />
                  </div>
                  <div className="md:col-span-3">
                    <label className="block text-[10px] text-zinc-500 uppercase font-bold mb-1">Batafsil matn</label>
                    <textarea
                      value={editAppLongDesc}
                      rows={3}
                      required
                      onChange={e => setEditAppLongDesc(e.target.value)}
                      className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-white resize-none"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingAppId(null)}
                    className="px-4 py-2 bg-black border border-zinc-800 rounded text-xs text-zinc-400 font-bold"
                  >
                    Bekor qilish
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-white text-black font-extrabold rounded text-xs"
                  >
                    Muvaffaqiyatli saqlash
                  </button>
                </div>
              </form>
            )}

            {/* List Table */}
            <div className="bg-black border border-zinc-850 rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-zinc-300">
                  <thead className="bg-zinc-950 text-zinc-400 font-bold border-b border-zinc-850">
                    <tr>
                      <th className="py-3 px-4 font-mono">ID</th>
                      <th className="py-3 px-4">Paket / Nomi</th>
                      <th className="py-3 px-4">Dasturchi</th>
                      <th className="py-3 px-2">Turkum</th>
                      <th className="py-3 px-2">Versiya</th>
                      <th className="py-3 px-2">Hajmi</th>
                      <th className="py-3 px-2">Yuklanish</th>
                      <th className="py-3 px-2 text-center">TOP Status</th>
                      <th className="py-3 px-4 text-right">Boshqaruv</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-900">
                    {filteredApps.map(app => (
                      <tr key={app.id} className="hover:bg-zinc-900/30">
                        <td className="py-3 px-4 font-mono text-[10px] text-zinc-600 font-bold">{app.id}</td>
                        <td className="py-3 px-4 flex items-center gap-3">
                          <img src={app.icon} alt={app.name} className="w-8 h-8 rounded-md object-cover border border-zinc-800" />
                          <div>
                            <p className="font-bold text-white text-xs">{app.name}</p>
                            <span className={`text-[8px] px-1 rounded font-mono border ${
                              app.status === 'approved' ? 'bg-zinc-900 text-white border-zinc-700' : 'bg-black text-zinc-500 border-zinc-850'
                            }`}>
                              {app.status.toUpperCase()}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-4 font-semibold text-zinc-400">{app.developer}</td>
                        <td className="py-3 px-2 font-mono text-zinc-400">{app.category}</td>
                        <td className="py-3 px-2 font-mono text-zinc-400">{app.version}</td>
                        <td className="py-3 px-2 font-mono text-zinc-400">{app.fileSize}</td>
                        <td className="py-3 px-2 font-mono font-bold text-white">{formatDownloads(app.downloadsCount)}</td>
                        <td className="py-3 px-2 text-center">
                          {app.status === 'approved' ? (
                            <button
                              id={`toggletop-${app.id}`}
                              onClick={() => {
                                onToggleTopApp(app.id);
                                showToast(`"${app.name}" tavsiya holati yangilandi`, "info");
                              }}
                              className={`py-1 px-2.5 rounded text-[10px] cursor-pointer border ${
                                app.isTop ? 'bg-white text-black border-white' : 'bg-transparent text-zinc-500 border-zinc-800 hover:text-white'
                              }`}
                            >
                              {app.isTop ? '★ TOP' : '☆ Oddiy'}
                            </button>
                          ) : (
                            <span className="text-zinc-600">-</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right space-x-1 whitespace-nowrap">
                          <button
                            onClick={() => openAppEditorForm(app)}
                            className="px-2 py-1 bg-zinc-900 hover:bg-zinc-800 text-white border border-zinc-800 rounded text-[10px] font-bold"
                          >
                            Tahrirlash
                          </button>
                          <button
                            onClick={() => handleDeleteApp(app.id, app.name)}
                            className="px-2 py-1 bg-zinc-950 hover:bg-rose-950 hover:text-rose-400 text-zinc-500 border border-zinc-900 rounded text-[10px] font-bold"
                          >
                            O'chirish
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* =======================================================
            TAB: FOYDALANUVCHILAR
            ======================================================= */}
        {activeTab === 'foydalanuvchilar' && (
          <div className="space-y-4" id="tab-foydalanuvchilar-grayscale">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-black uppercase text-white tracking-widest">Tizim a'zolari va foydalanuvchilar ro'yxati</h3>
                <p className="text-xs text-zinc-500">Ishtirokchilar parollarini o'zgartirish, bloklash yoki butunlay o'chirish huquqi.</p>
              </div>
              <input
                type="text"
                value={userSearchText}
                onChange={e => setUserSearchText(e.target.value)}
                placeholder="Qidiruv..."
                className="bg-black text-white border border-zinc-850 rounded px-3 py-1.5 text-xs w-full md:w-64 focus:outline-none focus:border-white"
              />
            </div>

            {/* Password inline editor drawer banner */}
            {editingUserId && (
              <div className="bg-zinc-950 border border-white rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-0.5">
                  <span className="text-xs text-white font-bold font-mono">Parolni almashtirish (#ID: {editingUserId})</span>
                  <p className="text-[10px] text-zinc-500">Iltimos, yangi maxfiy kalitni kiriting.</p>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Yangi parol..."
                    value={newPasswordVal}
                    onChange={e => setNewPasswordVal(e.target.value)}
                    className="bg-black border border-zinc-800 rounded px-3 py-1.5 text-xs text-white"
                  />
                  <button
                    onClick={() => saveNewUserPassword(editingUserId)}
                    className="px-4 py-1.5 bg-white text-black text-xs font-bold rounded"
                  >
                    Saqlash
                  </button>
                  <button
                    onClick={() => setEditingUserId(null)}
                    className="px-3 py-1.5 bg-black border border-zinc-850 rounded text-xs text-zinc-400"
                  >
                    Bekor
                  </button>
                </div>
              </div>
            )}

            {/* Users table */}
            <div className="bg-black border border-zinc-850 rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-zinc-300">
                  <thead className="bg-zinc-950 text-zinc-400 font-bold border-b border-zinc-850">
                    <tr>
                      <th className="py-3 px-4 font-mono">ID</th>
                      <th className="py-3 px-4">Ism & Familiya</th>
                      <th className="py-3 px-4">Elektron Pochta</th>
                      <th className="py-3 px-2">Amaldagi Parol</th>
                      <th className="py-3 px-2">Roli</th>
                      <th className="py-3 px-2">Kompaniya</th>
                      <th className="py-3 px-2 text-center">Blokli Holati</th>
                      <th className="py-3 px-4 text-right">Boshqaruv</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-900">
                    {filteredUsers.map(user => (
                      <tr key={user.id} className="hover:bg-zinc-900/30">
                        <td className="py-3 px-4 font-mono text-[11px] text-zinc-500 font-bold">{user.id}</td>
                        <td className="py-3 px-4 font-bold text-white">
                          {user.firstName} {user.lastName}
                        </td>
                        <td className="py-3 px-4 font-mono text-zinc-400">{user.email}</td>
                        <td className="py-3 px-2 font-mono text-zinc-500 font-bold">••••••</td>
                        <td className="py-3 px-2 font-bold uppercase text-[10px] text-zinc-400">{user.role}</td>
                        <td className="py-3 px-2 text-zinc-400 font-mono">{user.companyName || '-'}</td>
                        <td className="py-3 px-2 text-center">
                          {user.isBlocked ? (
                            <span className="px-2 py-0.5 bg-zinc-900 text-zinc-400 border border-zinc-850 rounded text-[9px] font-bold">BLOKLANGAN</span>
                          ) : (
                            <span className="px-2 py-0.5 bg-black text-emerald-400 border border-zinc-800 rounded text-[9px] font-bold">FAOL</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right space-x-1 whitespace-nowrap">
                          <button
                            onClick={() => {
                              setEditingUserId(user.id);
                              setNewPasswordVal('');
                            }}
                            className="px-2 py-1 bg-zinc-900 hover:bg-zinc-800 text-white rounded text-[10px] font-bold cursor-pointer"
                          >
                            Parol o'zgartirish
                          </button>
                          <button
                            onClick={() => handleToggleBlock(user.id, `${user.firstName || ''} ${user.lastName || ''}`, user.isBlocked)}
                            className="px-2 py-1 bg-black text-zinc-450 border border-zinc-800 rounded text-[10px] font-bold cursor-pointer"
                          >
                            {user.isBlocked ? "Ochish" : "Bloklash"}
                          </button>
                          <button
                            onClick={() => handleDeleteUser(user.id, `${user.firstName || ''} ${user.lastName || ''}`)}
                            className="px-2 py-1 bg-zinc-950 hover:bg-rose-950 hover:text-rose-450 border border-zinc-900 rounded text-[10px] font-bold cursor-pointer"
                          >
                            O'chirish
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* =======================================================
            TAB: XABARLAR YO'LLASH
            ======================================================= */}
        {activeTab === 'xabarlar-yuborish' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-none" id="tab-announce-grayscale">
            
            {/* Form Column */}
            <div className="lg:col-span-1 bg-black border border-zinc-805 p-5 rounded-xl h-fit space-y-4">
              <h3 className="text-xs uppercase font-black tracking-widest text-white border-b border-zinc-900 pb-2">Tizimli Bildirishnoma Yozish</h3>
              <p className="text-xs text-zinc-500">Ilovalar do'koni a'zolariga ommaviy (Broadcast) yoki xavfsiz shaxsiy xat yo'llang.</p>

              <form onSubmit={handleSendMessageSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-zinc-500 mb-1 tracking-wider">Kimga (Qabul qiluvchi)</label>
                  <select
                    value={msgRecipient}
                    onChange={e => setMsgRecipient(e.target.value)}
                    className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-white text-xs"
                  >
                    <option value="all">📢 Barcha foydalanuvchilarga (Broadcast)</option>
                    {users.map(u => (
                      <option key={u.id} value={u.id}>
                        👤 {u.firstName} {u.lastName} ({u.role})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-zinc-500 mb-1 tracking-wider">Mavzu nomi</label>
                  <input
                    type="text"
                    required
                    placeholder="Mavzuni yozing..."
                    value={msgTitle}
                    onChange={e => setMsgTitle(e.target.value)}
                    className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-white test-xs"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-zinc-500 mb-1 tracking-wider">Matn tarkibi</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Mazmunni bayon qiling..."
                    value={msgContent}
                    onChange={e => setMsgContent(e.target.value)}
                    className="w-full bg-black border border-zinc-800 rounded px-3 py-2 text-white resize-none text-xs"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-white text-black text-xs font-black py-2.5 rounded hover:bg-zinc-150 cursor-pointer flex items-center justify-center gap-2"
                >
                  <Send size={12} />
                  <span>Yuborish (Xabar berish)</span>
                </button>
              </form>
            </div>

            {/* Sent Log Row */}
            <div className="lg:col-span-2 space-y-4">
              <h3 className="text-xs uppercase font-black tracking-widest text-zinc-400 flex items-center gap-2 border-b border-zinc-850 pb-2">
                <Bell size={13} />
                <span>Yuborilgan tizimli xabarnomalar tarixi ({systemMessages.length})</span>
              </h3>

              {systemMessages.length === 0 ? (
                <p className="text-xs text-zinc-650 bg-black p-6 rounded border border-zinc-850 text-center">Xabarlar yuborilmagan.</p>
              ) : (
                <div className="space-y-3">
                  {systemMessages.map(msg => {
                    const recipientUser = users.find(u => u.id === msg.recipientId);
                    return (
                      <div key={msg.id} className="bg-zinc-950 border border-zinc-850 p-4 rounded-xl space-y-1 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="px-2 py-0.5 border border-zinc-800 text-[8px] font-bold rounded font-mono uppercase text-zinc-400">
                            {msg.recipientId === 'all' ? 'Broadcasting (Ommaviy)' : `Shaxsiy yuborilgan ID: ${msg.recipientId}`}
                          </span>
                          <span className="font-mono text-zinc-600 text-[10px]">{msg.date}</span>
                        </div>
                        <h4 className="text-sm font-extrabold text-white pt-1">{msg.title}</h4>
                        <p className="text-zinc-400 pt-1 leading-relaxed">{msg.content}</p>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>
        )}

        {/* =======================================================
            TAB: DIZAYN & RANG SOZLAMALARI (DYNAMIC THEME CONTROL)
            ======================================================= */}
        {activeTab === 'dizayn-sozlamalari' && (
          <div className="bg-black border border-zinc-850 p-6 rounded-xl max-w-2xl space-y-6" id="theme-settings-grayscale">
            <div>
              <h3 className="text-sm font-black uppercase text-white tracking-widest flex items-center gap-2">
                <Palette size={16} />
                <span>Ilova Ranglari va Dizayni (Hamma Foydalanuvchilar Uchun)</span>
              </h3>
              <p className="text-xs text-zinc-500 mt-1">
                Ushbu bo'limdan kiritilgan o'zgarishlar ilovalar do'konidagi har bir foydalanuvchiga real-vaqt rejimida darhol ta'sir qiladi.
              </p>
            </div>

            {/* Accent presets */}
            <div className="space-y-3">
              <h4 className="text-xs text-zinc-400 font-bold uppercase tracking-wider">Mavjud rang namunalari (Tezkor tanlash)</h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {presets.map(color => (
                  <button
                    key={color.hex}
                    type="button"
                    onClick={() => {
                      setCustomColorInput(color.hex);
                      onUpdateAppAccentColor(color.hex);
                      showToast(`Siz "${color.name}" rangini tanladingiz!`, "success");
                    }}
                    className={`p-3 border text-xs font-semibold rounded text-left flex items-center gap-2.5 transition-all cursor-pointer ${
                      appAccentColor.toLowerCase() === color.hex.toLowerCase()
                        ? 'border-white text-white bg-zinc-900'
                        : 'border-zinc-850 text-zinc-400 hover:text-white bg-transparent'
                    }`}
                  >
                    <span className="w-3.5 h-3.5 rounded-full inline-block border border-zinc-800" style={{ backgroundColor: color.hex }} />
                    <span className="truncate">{color.name.split(' (')[0]}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom HEX code input */}
            <form onSubmit={handleSaveThemeSettings} className="space-y-4 pt-4 border-t border-zinc-900">
              <div className="space-y-1">
                <label className="block text-xs font-bold text-zinc-400 uppercase tracking-widest">
                  Custom Hex Rang kodini kiriting
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    maxLength={7}
                    placeholder="#2e7d32"
                    value={customColorInput}
                    onChange={(e) => setCustomColorInput(e.target.value)}
                    className="bg-black border border-zinc-800 text-white rounded px-3 py-2 text-xs font-mono w-40 uppercase"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2 bg-white text-black font-extrabold text-xs rounded hover:bg-zinc-150 transition-colors"
                  >
                    Fiksatsiya qilish / Saqlash
                  </button>
                </div>
              </div>
            </form>

            {/* Background Vibe switcher */}
            <div className="space-y-2 pt-4 border-t border-zinc-900">
              <h4 className="text-xs text-zinc-450 font-bold uppercase tracking-wider">Do'kon fon mavzusi</h4>
              <div className="flex gap-4">
                {[
                  { id: 'dark', label: 'Dark (Tungi/Qora rejim)', bg: 'bg-black text-white' },
                  { id: 'light', label: 'Light (Kunduzgi/Oq rejim)', bg: 'bg-white text-black' }
                ].map(vibe => (
                  <button
                    key={vibe.id}
                    type="button"
                    onClick={() => {
                      onUpdateAppBgStyle(vibe.id as 'dark' | 'light');
                      showToast(`Do'kon mavzusi ${vibe.id === 'dark' ? 'Qora rang' : 'Oq rang'} qilib belgilandi!`, "success");
                    }}
                    className={`px-4 py-2.5 rounded border text-xs font-bold font-mono tracking-tight cursor-pointer ${
                      appBgStyle === vibe.id
                        ? 'border-white bg-zinc-900 text-white shadow-md'
                        : 'border-zinc-850 text-zinc-500 hover:text-white'
                    }`}
                  >
                    {vibe.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

      </main>

    </div>
  );
};
