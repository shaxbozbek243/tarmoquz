import React, { useEffect } from 'react';
import { ToastMessage } from '../types';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

interface ToastContainerProps {
  toasts: ToastMessage[];
  onRemove: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onRemove }) => {
  return (
    <div 
      className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-sm w-full pointer-events-none" 
      id="toast-notifications-container"
    >
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onRemove={onRemove} />
      ))}
    </div>
  );
};

const ToastItem: React.FC<{ toast: ToastMessage; onRemove: (id: string) => void }> = ({
  toast,
  onRemove
}) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onRemove(toast.id);
    }, 3000);
    return () => clearTimeout(timer);
  }, [toast.id, onRemove]);

  const config = {
    success: {
      bg: 'bg-emerald-950 border-emerald-500 text-emerald-200',
      icon: <CheckCircle2 className="text-emerald-400 shrink-0" size={20} />,
      label: 'Muvaffaqiyatli'
    },
    error: {
      bg: 'bg-rose-950 border-rose-500 text-rose-200',
      icon: <AlertCircle className="text-rose-400 shrink-0" size={20} />,
      label: 'Xatolik'
    },
    info: {
      bg: 'bg-blue-950 border-blue-500 text-blue-200',
      icon: <Info className="text-blue-400 shrink-0" size={20} />,
      label: 'Ma\'lumot'
    }
  }[toast.type];

  return (
    <div
      id={`toast-${toast.id}`}
      className={`pointer-events-auto flex items-start gap-3 p-4 rounded-xl border ${config.bg} shadow-2xl transition-all duration-300 transform translate-y-0`}
    >
      {config.icon}
      <div className="flex-1">
        <p className="font-semibold text-xs opacity-75 uppercase tracking-wide">{config.label}</p>
        <p className="text-sm font-medium mt-0.5">{toast.text}</p>
      </div>
      <button
        type="button"
        id={`toast-close-${toast.id}`}
        onClick={() => onRemove(toast.id)}
        className="text-current opacity-60 hover:opacity-100 p-0.5 rounded-lg hover:bg-white/10"
      >
        <X size={16} />
      </button>
    </div>
  );
};
