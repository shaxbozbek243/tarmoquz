import React, { useState } from 'react';
import { User } from '../types';
import { fileToBase64 } from '../utils';
import { ShoppingBag, Eye, EyeOff, User as UserIcon, Rocket, Shield, Building, ArrowLeft, Check } from 'lucide-react';

interface AuthViewProps {
  onSuccess: (user: User) => void;
  onNavigateBack: () => void;
  users: User[];
  onAddUser: (user: User) => void;
  showToast: (text: string, type: 'success' | 'error' | 'info') => void;
}

export const AuthView: React.FC<AuthViewProps> = ({
  onSuccess,
  onNavigateBack,
  users,
  onAddUser,
  showToast
}) => {
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  
  // Login form states
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  // Common register states
  const [regRole, setRegRole] = useState<'user' | 'creator'>('user');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  // Creator specific states
  const [companyName, setCompanyName] = useState('');
  const [companyLogo, setCompanyLogo] = useState('');
  const [bio, setBio] = useState('');

  // Password visibility
  const [showPass, setShowPass] = useState(false);

  // Robot Challenge Checkbox (Bypassed by default for sleek and non-blocking experience)
  const [isRobotChecked, setIsRobotChecked] = useState(true);
  const [isRobotVerifying, setIsRobotVerifying] = useState(false);

  // Google Modal Accounts
  const [showGoogleModal, setShowGoogleModal] = useState(false);
  const [customGoogleEmail, setCustomGoogleEmail] = useState('');
  const [isCustomGoogleInput, setIsCustomGoogleInput] = useState(false);

  const defaultGoogleEmail = "773649664s@gmail.com";

  // Checkbox activation
  const handleRobotCheckClick = () => {
    if (isRobotChecked || isRobotVerifying) return;
    setIsRobotVerifying(true);
    setTimeout(() => {
      setIsRobotVerifying(false);
      setIsRobotChecked(true);
      showToast("Xavfsizlik tekshiruvi: Siz odamsiz!", "success");
    }, 900);
  };

  // Google Sign In trigger
  const handleGoogleSignInClick = () => {
    setShowGoogleModal(true);
  };

  const handleSelectGoogleAccount = (selectedEmail: string) => {
    // Check if user exists, else auto-register as user
    let existingUser = users.find(u => u.email.toLowerCase() === selectedEmail.toLowerCase());
    if (!existingUser) {
      existingUser = {
        id: `google_${Date.now()}`,
        role: 'user',
        email: selectedEmail,
        firstName: selectedEmail.split('@')[0],
        lastName: 'Google Foydalanuvchisi',
        isBlocked: false,
        downloadedAppIds: []
      };
      onAddUser(existingUser);
      showToast(`Google orqali yangi hisob yaratildi: ${selectedEmail}`, "success");
    } else {
      if (existingUser.isBlocked) {
        showToast("Kechirasiz, ushbu hisob bloklangan!", "error");
        return;
      }
      showToast(`Google orqali kirdingiz: ${selectedEmail}`, "success");
    }
    setShowGoogleModal(false);
    onSuccess(existingUser);
  };

  // Handle Logo Upload
  const handleLogoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const base64 = await fileToBase64(file);
        setCompanyLogo(base64);
        showToast("Kompaniya logosi yuklandi", "success");
      } catch (err) {
        showToast("Rasm yuklashda xatolik", "error");
      }
    }
  };

  // Submit Login
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isRobotChecked) {
      showToast("Iltimos, avval robot emasligingizni tasdiqlang!", "error");
      return;
    }

    // 1. Check for Secret Administrator login
    const isSecretAdmin = (loginEmail.trim() === 'adminuzno1' && loginPassword === 'admineme');
    const isSimpleAdmin = ((loginEmail.trim().toLowerCase() === 'admin' || loginEmail.trim().toLowerCase() === 'admin@tarmoq.uz') && loginPassword === 'admin');
    
    if (isSecretAdmin || isSimpleAdmin) {
      const adminUser: User = {
        id: 'admin_user',
        role: 'admin',
        email: 'admin@tarmoq.uz',
        firstName: 'Tizim',
        lastName: 'Administratori',
        isBlocked: false,
        downloadedAppIds: []
      };
      showToast("Siz administrator sifatida muvaffaqiyatli kirdingiz!", "success");
      onSuccess(adminUser);
      return;
    }

    // 2. Normal User or Creator Login
    const foundUser = users.find(u => u.email.toLowerCase() === loginEmail.trim().toLowerCase());
    
    if (!foundUser) {
      showToast("Elektron pochta yoki parol hato!", "error");
      return;
    }

    if (foundUser.password !== loginPassword) {
      showToast("Elektron pochta yoki parol hato!", "error");
      return;
    }

    if (foundUser.isBlocked) {
      showToast("Kechirasiz, ushbu hisob bloklangan!", "error");
      return;
    }

    showToast(`Xush kelibsiz, ${foundUser.firstName}!`, "success");
    onSuccess(foundUser);
  };

  // Submit Register
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!isRobotChecked) {
      showToast("Iltimos, avval robot emasligingizni tasdiqlang!", "error");
      return;
    }

    if (!firstName.trim() || !lastName.trim() || !email.trim() || !password || !confirmPassword) {
      showToast("Iltimos, barcha majburiy maydonlarni to'ldiring!", "error");
      return;
    }

    if (password !== confirmPassword) {
      showToast("Parollar mos kelmadi!", "error");
      return;
    }

    if (password.length < 6) {
      showToast("Parol kamida 6 ta belgidan iborat bo'lishi kerak!", "error");
      return;
    }

    const isDuplicate = users.some(u => u.email.toLowerCase() === email.trim().toLowerCase());
    if (isDuplicate) {
      showToast("Ushbu pochta bilan allaqachon ro'yxatdan o'tilgan!", "error");
      return;
    }

    if (regRole === 'creator' && !companyName.trim()) {
      showToast("Developer uchun Kompaniya nomi kiritilishi shart!", "error");
      return;
    }

    const newUser: User = {
      id: `user_${Date.now()}`,
      role: regRole,
      email: email.trim(),
      password: password,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      companyName: regRole === 'creator' ? companyName.trim() : undefined,
      companyLogo: regRole === 'creator' ? (companyLogo || undefined) : undefined,
      bio: regRole === 'creator' ? (bio.trim() || undefined) : undefined,
      isBlocked: false,
      downloadedAppIds: []
    };

    onAddUser(newUser);
    showToast("Muvaffaqiyatli ro'yxatdan o'tdingiz!", "success");
    onSuccess(newUser);
  };

  return (
    <div className="max-w-md mx-auto px-4 py-8" id="auth-view-root">
      {/* Back button */}
      <button
        type="button"
        id="btn-back-to-landing"
        onClick={onNavigateBack}
        className="flex items-center gap-2 text-xs text-gray-400 hover:text-white mb-6 cursor-pointer focus:outline-none"
      >
        <ArrowLeft size={16} />
        <span>Bosh sahifaga qaytish</span>
      </button>

      {/* Brand Header */}
      <div className="text-center mb-8" id="auth-brand-header">
        <div className="inline-flex p-3 bg-white/5 rounded-3xl mb-3 border border-white/10">
          <ShoppingBag size={32} className="text-white" />
        </div>
        <h2 className="text-2xl font-black text-white tracking-tight">
          Tarmoq Market
        </h2>
        <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto">
          Ilovalar va o'yinlar dunyosiga kirish
        </p>
      </div>

      {/* Tab Selectors */}
      <div className="grid grid-cols-2 bg-[#1c1c1e] p-1 rounded-full border border-[#2c2c2e] mb-6" id="auth-tabs">
        <button
          type="button"
          id="tab-btn-login"
          onClick={() => setActiveTab('login')}
          className={`py-2 rounded-full text-xs font-semibold cursor-pointer transition-colors duration-200 ${
            activeTab === 'login'
              ? 'bg-white text-black'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          Kirish
        </button>
        <button
          type="button"
          id="tab-btn-register"
          onClick={() => setActiveTab('register')}
          className={`py-2 rounded-full text-xs font-semibold cursor-pointer transition-colors duration-200 ${
            activeTab === 'register'
              ? 'bg-white text-black'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          Ro'yxatdan o'tish
        </button>
      </div>

      {/* Main Container */}
      <div className="bg-[#1c1c1e] border border-[#2c2c2e] rounded-3xl p-6 md:p-8" id="auth-form-card">
        
        {/* Google Authentication */}
        <div className="mb-5">
          <button
            type="button"
            onClick={handleGoogleSignInClick}
            className="w-full py-2.5 bg-white text-black hover:bg-gray-150 rounded-xl cursor-pointer text-xs font-bold flex items-center justify-center gap-2 border border-gray-200 shadow transition-colors"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#EA4335"
                d="M12 5.04c1.66 0 3.2.57 4.38 1.69l3.27-3.27C17.67 1.47 14.99 1 12 1 7.24 1 3.2 4.04 1.61 8.35l3.89 3.01C6.44 7.63 8.96 5.04 12 5.04z"
              />
              <path
                fill="#4285F4"
                d="M23.49 12.27c0-.81-.07-1.59-.2-2.36H12v4.51h6.46c-.29 1.48-1.14 2.73-2.42 3.57v2.96h3.89c2.28-2.1 3.56-5.19 3.56-8.68z"
              />
              <path
                fill="#FBBC05"
                d="M5.5 14.64c-.25-.72-.39-1.5-.39-2.31s.14-1.59.39-2.31L1.61 7.01C.58 9.03 0 11.23 0 12.5s.58 3.47 1.61 5.49l3.89-3.35z"
              />
              <path
                fill="#34A853"
                d="M12 23c3.24 0 5.97-1.07 7.96-2.92l-3.89-2.96c-1.1.74-2.51 1.18-4.07 1.18-3.04 0-5.56-2.59-6.5-6.32l-3.39 3c1.59 4.31 5.63 7.1 10.39 7.1z"
              />
            </svg>
            <span>Google orqali kirish</span>
          </button>
          
          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-[#2c2c2e]"></span>
            </div>
            <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-widest">
              <span className="bg-[#1c1c1e] px-3 text-gray-400">Yoki elektron pochta bilan</span>
            </div>
          </div>
        </div>

        {activeTab === 'login' ? (
          /* LOGIN FORM */
          <form onSubmit={handleLoginSubmit} className="space-y-4" id="form-login">
            <div className="space-y-1">
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                Elektron pochta manzili
              </label>
              <input
                id="login-email-input"
                type="text"
                required
                placeholder="misol@tarmoq.uz yoki login"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none transition-colors"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                Kirish paroli
              </label>
              <div className="relative">
                <input
                  id="login-password-input"
                  type={showPass ? "text" : "password"}
                  required
                  placeholder="••••••••"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl pl-4 pr-10 py-3 text-xs focus:outline-none transition-colors"
                />
                <button
                  type="button"
                  id="btn-toggle-show-pass"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-3.5 text-gray-500 hover:text-white cursor-pointer"
                >
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              id="btn-submit-auth"
              className="w-full py-3 mt-4 text-xs font-bold rounded-xl shadow-md transition-all duration-200 bg-white hover:bg-gray-200 text-black cursor-pointer"
            >
              Tizimga kirish
            </button>
          </form>
        ) : (
          /* REGISTRATION FORM */
          <form onSubmit={handleRegisterSubmit} className="space-y-4" id="form-register">
            {/* Role selection */}
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                Tizimdagi rolingiz
              </label>
              <div className="grid grid-cols-2 gap-3" id="role-selector">
                <button
                  type="button"
                  id="role-btn-user"
                  onClick={() => setRegRole('user')}
                  className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-full text-xs font-semibold border cursor-pointer transition-all ${
                    regRole === 'user'
                      ? 'bg-white border-transparent text-black'
                      : 'bg-transparent border-[#2c2c2e] text-gray-400 hover:text-white hover:bg-[#2c2c2e]'
                  }`}
                >
                  <UserIcon size={14} />
                  <span>Foydalanuvchi</span>
                </button>
                <button
                  type="button"
                  id="role-btn-creator"
                  onClick={() => setRegRole('creator')}
                  className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-full text-xs font-semibold border cursor-pointer transition-all ${
                    regRole === 'creator'
                      ? 'bg-white border-transparent text-black'
                      : 'bg-transparent border-[#2c2c2e] text-gray-400 hover:text-white hover:bg-[#2c2c2e]'
                  }`}
                >
                  <Rocket size={14} />
                  <span>Dasturchi (Creator)</span>
                </button>
              </div>
            </div>

            {/* Main personal fields */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Ism</label>
                <input
                  id="reg-firstname"
                  type="text"
                  required
                  placeholder="Sardor"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-3 py-2.5 text-xs focus:outline-none"
                />
              </div>
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Familiya</label>
                <input
                  id="reg-lastname"
                  type="text"
                  required
                  placeholder="Rahimov"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-3 py-2.5 text-xs focus:outline-none"
                />
              </div>
            </div>

            {/* Creator specialized fields */}
            {regRole === 'creator' && (
              <div className="space-y-3 p-4 bg-black/30 border border-[#2c2c2e] rounded-2xl" id="creator-additional-fields">
                <p className="text-[10px] font-bold text-white flex items-center gap-1.5 uppercase tracking-wider">
                  <Building size={12} />
                  <span>Kompaniya Ma'lumotlari</span>
                </p>

                <div className="space-y-1">
                  <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-wider">Kompaniya nomi</label>
                  <input
                    id="reg-company-name"
                    type="text"
                    required={regRole === 'creator'}
                    placeholder="Masalan: Click Up dev"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-3 py-2 text-xs focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-wider">Logo</label>
                  <div className="flex items-center gap-3">
                    <input
                      id="reg-company-logo-file"
                      type="file"
                      accept="image/*"
                      onChange={handleLogoChange}
                      className="hidden"
                    />
                    <button
                      type="button"
                      id="btn-upload-logo-trigger"
                      onClick={() => document.getElementById('reg-company-logo-file')?.click()}
                      className="px-3 py-2 bg-zinc-900 hover:bg-zinc-800 text-gray-300 border border-[#2c2c2e] text-xs font-semibold rounded-xl cursor-pointer"
                    >
                      Logoni yuklash
                    </button>
                    {companyLogo ? (
                      <img
                        src={companyLogo}
                        alt="Logo preview"
                        className="w-10 h-10 rounded-lg object-cover border border-[#2c2c2e]"
                      />
                    ) : (
                      <span className="text-[10px] text-gray-500">Logo kiritilmagan</span>
                    )}
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-wider">Ta'rif</label>
                  <textarea
                    id="reg-bio"
                    placeholder="Kompaniya haqida..."
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    rows={2}
                    className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-3 py-2 text-xs focus:outline-none resize-none"
                  />
                </div>
              </div>
            )}

            <div className="space-y-1">
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Elektron pochta</label>
              <input
                id="reg-email"
                type="email"
                required
                placeholder="misol@tarmoq.uz"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-2.5 text-xs focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Parol</label>
                <input
                  id="reg-password"
                  type="password"
                  required
                  placeholder="Min. 6 belgi"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-3 py-2.5 text-xs focus:outline-none"
                />
              </div>
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Tasdiqlash</label>
                <input
                  id="reg-confirm-password"
                  type="password"
                  required
                  placeholder="Qayta yozing"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-3 py-2.5 text-xs focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              id="reg-submit-btn"
              className="w-full py-3 mt-4 text-xs font-bold rounded-xl shadow-md transition-all duration-200 bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
            >
              Yangi hisob yaratish
            </button>
          </form>
        )}
      </div>

      {/* Real Google Account Selection Auth Modal */}
      {showGoogleModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4" id="google-accounts-modal">
          <div className="bg-[#1c1c1e] border border-zinc-800 rounded-2xl w-full max-w-sm overflow-hidden p-6 space-y-4 shadow-2xl">
            <div className="flex flex-col items-center text-center space-y-2">
              {/* Google multi-colored icon banner */}
              <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center shadow-md">
                <svg className="w-7 h-7" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.2 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
              </div>
              <h3 className="text-base font-bold text-white tracking-tight mt-1">Google orqali hisobni tanlang</h3>
              <p className="text-xs text-gray-400">Tarmoq Market tizimiga bitta bosish orqali xavfsiz ulanish</p>
            </div>

            <div className="space-y-2 mt-4" id="google-accounts-list">
              {/* Actual Google User Account from context */}
              <button
                type="button"
                onClick={() => handleSelectGoogleAccount(defaultGoogleEmail)}
                className="w-full bg-zinc-900/65 hover:bg-zinc-800 text-left p-3.5 rounded-xl border border-zinc-805/50 cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-extrabold text-xs">
                    G
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block">Sizning faol profilingiz</span>
                    <span className="text-[10px] text-gray-400 block font-mono">{defaultGoogleEmail}</span>
                  </div>
                </div>
                <span className="text-[9px] uppercase font-bold text-emerald-400 font-mono tracking-wider bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-900">Faol</span>
              </button>

              {/* Show option inputting another Google active account */}
              {!isCustomGoogleInput ? (
                <button
                  type="button"
                  onClick={() => setIsCustomGoogleInput(true)}
                  className="w-full hover:bg-zinc-900 text-center py-2 text-zinc-400 hover:text-white text-xs font-semibold cursor-pointer border border-dashed border-zinc-800 rounded-xl mt-1 block"
                >
                  + Boshqa Google hisobini qo'shish
                </button>
              ) : (
                <div className="space-y-2 border-t border-zinc-800 pt-3 mt-2 animate-none">
                  <span className="text-[9px] uppercase font-bold text-zinc-400 block tracking-wide">Google pochtangizni kiritish</span>
                  <div className="flex gap-2">
                    <input
                      type="email"
                      value={customGoogleEmail}
                      onChange={(e) => setCustomGoogleEmail(e.target.value)}
                      placeholder="masalan: developer@gmail.com"
                      className="flex-1 bg-zinc-950 border border-zinc-800 focus:border-sky-500 rounded-xl px-3 py-2 text-xs text-white"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (!customGoogleEmail.trim() || !customGoogleEmail.includes('@')) {
                          showToast("Iltimos, haqiqiy Google pochtasini yozing!", "error");
                          return;
                        }
                        handleSelectGoogleAccount(customGoogleEmail.trim());
                      }}
                      className="px-3 bg-white text-black font-extrabold text-xs rounded-xl"
                    >
                      Kirish
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsCustomGoogleInput(false)}
                    className="text-[9px] text-zinc-500 hover:text-white block mt-1"
                  >
                    Ortga qaytish
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={() => setShowGoogleModal(false)}
              className="w-full text-center py-2.5 text-xs text-zinc-500 hover:text-white font-bold block pt-3 border-t border-zinc-900"
            >
              Bekor qilish
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
