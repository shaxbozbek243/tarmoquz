import React from 'react';
import { Star } from 'lucide-react';

interface RatingStarsProps {
  rating: number;
  max?: number;
  size?: number;
  interactive?: boolean;
  onChange?: (rating: number) => void;
}

export const RatingStars: React.FC<RatingStarsProps> = ({
  rating,
  max = 5,
  size = 16,
  interactive = false,
  onChange
}) => {
  const roundedRating = Math.round(rating * 10) / 10;

  return (
    <div className="flex items-center gap-1" id="rating-stars-container">
      {Array.from({ length: max }).map((_, i) => {
        const starIndex = i + 1;
        const isFilled = interactive ? starIndex <= rating : starIndex <= roundedRating;
        const isHalf = !interactive && starIndex > roundedRating && starIndex - 0.5 <= roundedRating;

        return (
          <button
            key={i}
            id={`star-btn-${i}`}
            type="button"
            disabled={!interactive}
            onClick={() => interactive && onChange && onChange(starIndex)}
            className={`${interactive ? 'cursor-pointer hover:scale-110 active:scale-95' : 'cursor-default'} focus:outline-none`}
            style={{ width: size, height: size }}
          >
            <Star
              size={size}
              className={`${
                isFilled
                  ? 'fill-[#ffc107] text-[#ffc107]'
                  : isHalf
                  ? 'fill-gradient text-[#ffc107]' // we can render semi fill
                  : 'text-gray-600 fill-transparent'
              }`}
              style={
                isHalf
                  ? {
                      stroke: '#ffc107',
                      fill: 'currentColor',
                      clipPath: 'polygon(0 0, 50% 0, 50% 100%, 0% 100%)',
                      position: 'absolute'
                    }
                  : {}
              }
            />
            {isHalf && (
              <Star
                size={size}
                className="text-gray-600 fill-transparent"
              />
            )}
          </button>
        );
      })}
    </div>
  );
};
