import React from 'react';
import { AppItem } from '../types';
import { CATEGORIES } from '../data';
import { RatingStars } from './RatingStars';
import { formatDownloads, getAverageRating } from '../utils';
import { ArrowRight, ShoppingBag, Eye, LogIn } from 'lucide-react';

interface LandingViewProps {
  apps: AppItem[];
  onNavigateToAuth: () => void;
  onSelectCategory: (category: string) => void;
  selectedCategory: string;
}

export const LandingView: React.FC<LandingViewProps> = ({
  apps,
  onNavigateToAuth,
  onSelectCategory,
  selectedCategory
}) => {
  // Filter for approved apps on landing
  const filteredApps = apps.filter(app => {
    if (selectedCategory === 'Barchasi') return app.status === 'approved';
    return app.category === selectedCategory && app.status === 'approved';
  });

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-6 mb-12" id="landing-view-root">
      {/* Upper Navigation Header */}
      <header className="flex items-center justify-between border-b border-[#2c2c2e] pb-5 mb-8 bg-[#0f0f0f]" id="landing-header">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 accent-bg rounded-lg flex items-center justify-center shadow-md">
            <ShoppingBag size={18} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-1">
              Tarmoq <span className="accent-text">Market</span>
            </h1>
            <p className="text-[9px] text-gray-500 font-mono tracking-widest uppercase mt-0.5">MILLIY DO'KON</p>
          </div>
        </div>
        <button
          type="button"
          id="btn-login-landing"
          onClick={onNavigateToAuth}
          className="flex items-center gap-2 px-6 py-2.5 bg-[#1c1c1e] hover:bg-[#2c2c2e] text-white border border-[#2c2c2e] rounded-full font-medium text-xs cursor-pointer transition-colors duration-200"
        >
          <LogIn size={14} className="accent-text" />
          <span>Tizimga kirish</span>
        </button>
      </header>

      {/* Static Hero Banner */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#1a2b4b] to-[#0a1a33] mb-10 border border-[#2c2c2e]" id="landing-hero-banner">
        {/* Background Decorative Blur Graphic */}
        <div className="absolute right-0 top-0 h-full w-1/2 opacity-25 accent-bg blur-3xl pointer-events-none" />
        
        {/* Banner Content */}
        <div className="relative z-20 px-8 py-12 md:px-12 md:py-14 max-w-2xl flex flex-col items-start">
          <span className="inline-block px-3 py-1 accent-bg text-white text-[9px] font-bold uppercase rounded-md tracking-wider mb-4">
            Yilning eng sara loyihasi
          </span>
          <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-none">
            Milliy ilovalar va o'yinlar dunyosiga kiring
          </h2>
          <p className="text-gray-300 text-sm mt-3 leading-relaxed max-w-lg">
            Tarmoq Market — O'zbekiston dasturchilari tomonidan yaratilgan eng sara mobil xizmatlar, o'yinlar va qulay moliyaviy dasturlar jamlangan milliy platformadir.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-5">
            <button
              type="button"
              id="btn-explore-hero"
              onClick={onNavigateToAuth}
              className="px-8 py-3 bg-white hover:bg-gray-100 text-black rounded-full font-semibold text-sm flex items-center gap-2 cursor-pointer transition-colors duration-200"
            >
              <span>Batafsil ko'rish</span>
              <ArrowRight size={15} />
            </button>
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              <span>100% Xavfsiz yuklab olish</span>
            </div>
          </div>
        </div>
      </section>

      {/* Category Selection Filter Line */}
      <section className="mb-10" id="landing-categories">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white tracking-tight">Turkumlar bo'yicha filterlash</h3>
        </div>
        <div className="flex items-center gap-2 overflow-x-auto pb-3 scrollbar-none" id="category-chips-row">
          {CATEGORIES.map(category => (
            <button
              key={category}
              id={`chip-${category.replace(/\s+/g, '-').toLowerCase()}`}
              type="button"
              onClick={() => onSelectCategory(category)}
              className={`px-5 py-2 rounded-full text-xs font-medium cursor-pointer whitespace-nowrap transition-colors duration-200 ${
                selectedCategory === category
                  ? 'accent-bg text-white'
                  : 'bg-[#1c1c1e] hover:bg-[#2c2c2e] text-gray-400 border border-[#2c2c2e]'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </section>

      {/* App grid */}
      <section id="landing-app-showcase">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white tracking-tight">
            {selectedCategory === 'Barchasi' ? 'Tavsiya etilgan ilovalar' : `${selectedCategory} turkumidagi ilovalar`}
          </h3>
          <span className="text-xs text-gray-500">
            Jami: {filteredApps.length} ta
          </span>
        </div>

        {filteredApps.length === 0 ? (
          <div className="text-center py-16 bg-[#1c1c1e] rounded-3xl border border-[#2c2c2e]">
            <p className="text-gray-400 text-sm">Ushbu kategoriya bo'yicha tasdiqlangan ilovalar hozircha mavjud emas.</p>
            <button
              type="button"
              onClick={onNavigateToAuth}
              className="mt-4 text-xs font-bold accent-text hover:underline cursor-pointer"
            >
              Ilova qo'shish yoki Kirish ➔
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6" id="landing-apps-grid">
            {filteredApps.map(app => {
              const avgRating = getAverageRating(app);
              return (
                <div
                  key={app.id}
                  id={`landing-card-${app.id}`}
                  onClick={onNavigateToAuth}
                  className="bg-[#1c1c1e] hover:bg-[#2c2c2e] border border-[#2c2c2e] p-4 rounded-[22px] flex flex-col justify-between cursor-pointer transition-colors duration-200 group"
                >
                  <div className="flex flex-col gap-3">
                    {/* App icon image wrapper inside elegant aspect container */}
                    <div className="aspect-square bg-[#1c1c1e] rounded-2xl border border-[#2c2c2e]/60 flex items-center justify-center overflow-hidden transition-colors group-hover:bg-[#2c2c2e]/40">
                      <img
                        src={app.icon}
                        alt={`${app.name} icon`}
                        referrerPolicy="no-referrer"
                        className="w-20 h-20 rounded-2xl border border-[#2c2c2e] object-cover"
                      />
                    </div>
                    <div className="mt-1">
                      <span className="text-[9px] font-bold accent-text uppercase font-mono tracking-wider">
                        {app.category}
                      </span>
                      <h4 className="text-sm font-bold text-white tracking-tight truncate mt-0.5">
                        {app.name}
                      </h4>
                      <p className="text-xs text-gray-400 font-medium truncate">
                        {app.developer}
                      </p>
                    </div>
                    <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed">
                      {app.shortDescription}
                    </p>
                  </div>

                  <div className="pt-3 mt-4 border-t border-[#2c2c2e] flex items-center justify-between text-xs text-gray-400">
                    <div className="flex items-center gap-1.5">
                      <span className="text-amber-400">★</span>
                      <span className="font-semibold text-white">{avgRating > 0 ? avgRating : '0.0'}</span>
                    </div>
                    <div className="font-semibold font-mono text-[11px] text-gray-400">
                      {formatDownloads(app.downloadsCount)}+ yuklangan
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Aesthetic pairing footer */}
      <footer className="mt-20 border-t border-[#2c2c2e] pt-8 pb-12 flex flex-col md:flex-row items-center justify-between gap-4" id="landing-footer">
        <p className="text-xs text-gray-600 font-mono">
          Tarmoq Market © 2026. Barcha huquqlar himoyalangan.
        </p>
        <div className="flex items-center gap-4 text-xs text-gray-500">
          <span className="hover:text-white cursor-pointer transition-colors" onClick={onNavigateToAuth}>Foydalanish qoidalari</span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#2c2c2e]"></span>
          <span className="hover:text-white cursor-pointer transition-colors" onClick={onNavigateToAuth}>Yordam</span>
        </div>
      </footer>
    </div>
  );
};
