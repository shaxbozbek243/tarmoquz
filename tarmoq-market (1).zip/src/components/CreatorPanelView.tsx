import React, { useState } from 'react';
import { AppItem, User } from '../types';
import { fileToBase64, formatDownloads } from '../utils';
import { ShoppingBag, LogOut, LayoutDashboard, Folder, PlusCircle, BarChart3, Settings, Edit, CheckCircle, Clock, Trash2, ShieldAlert } from 'lucide-react';

interface CreatorPanelViewProps {
  currentUser: User;
  onLogout: () => void;
  apps: AppItem[];
  onAddApp: (app: Omit<AppItem, 'id' | 'creatorId' | 'developer' | 'downloadsCount' | 'ratingsCount' | 'ratingsSum' | 'isTop' | 'reviews'>) => void;
  onDeleteApp: (appId: string) => void;
  onUpdateCreatorProfile: (companyName: string, firstName: string, bio: string, companyLogo?: string, password?: string) => void;
  onUpdateAppFields: (appId: string, fields: Partial<AppItem>) => void;
  showToast: (text: string, type: 'success' | 'error' | 'info') => void;
}

export const CreatorPanelView: React.FC<CreatorPanelViewProps> = ({
  currentUser,
  onLogout,
  apps,
  onAddApp,
  onDeleteApp,
  onUpdateCreatorProfile,
  onUpdateAppFields,
  showToast
}) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'ilovalarim' | 'ilova-qoshish' | 'analytics' | 'profil'>('dashboard');

  // Edit app state
  const [editingApp, setEditingApp] = useState<AppItem | null>(null);

  // New App Form States
  const [appName, setAppName] = useState('');
  const [appShortDesc, setAppShortDesc] = useState('');
  const [appLongDesc, setAppLongDesc] = useState('');
  const [appCategory, setAppCategory] = useState('Ilovalar');
  const [appVersion, setAppVersion] = useState('1.0.0');
  const [appPlatform, setAppPlatform] = useState('Android');
  const [appSize, setAppSize] = useState('');
  const [appIcon, setAppIcon] = useState('');
  const [appScreenshots, setAppScreenshots] = useState<string[]>([]);
  const [apkFileName, setApkFileName] = useState('');

  // Editing App Form States
  const [editName, setEditName] = useState('');
  const [editShortDesc, setEditShortDesc] = useState('');
  const [editLongDesc, setEditLongDesc] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editVersion, setEditVersion] = useState('');
  const [editPlatform, setEditPlatform] = useState('');
  const [editSize, setEditSize] = useState('');
  const [editIcon, setEditIcon] = useState('');
  const [editScreenshots, setEditScreenshots] = useState<string[]>([]);
  const [editApkFileName, setEditApkFileName] = useState('');

  // Profile Edit States
  const [profCompanyName, setProfCompanyName] = useState(currentUser.companyName || '');
  const [profFirstName, setProfFirstName] = useState(currentUser.firstName || '');
  const [profBio, setProfBio] = useState(currentUser.bio || '');
  const [profLogo, setProfLogo] = useState(currentUser.companyLogo || '');
  const [profPassword, setProfPassword] = useState('');

  const creatorApps = apps.filter(app => app.creatorId === currentUser.id);

  // Stats
  const totalAppsCount = creatorApps.length;
  const approvedAppsCount = creatorApps.filter(a => a.status === 'approved').length;
  const pendingAppsCount = creatorApps.filter(a => a.status === 'pending').length;
  const rejectedAppsCount = creatorApps.filter(a => a.status === 'rejected').length;
  const cumulativeDownloads = creatorApps.reduce((acc, curr) => acc + curr.downloadsCount, 0);

  // APK file parsing logic
  const parseApkFile = (file: File, isEdit: boolean) => {
    if (!file.name.endsWith('.apk')) {
      showToast("Iltimos, haqiqiy .apk formatidagi faylni yuklang!", "error");
      return;
    }
    const calculatedSize = (file.size / (1024 * 1024)).toFixed(1) + ' MB';
    if (isEdit) {
      setEditApkFileName(file.name);
      setEditSize(calculatedSize);
      showToast(`Yangi APK yuklandi: ${file.name} (${calculatedSize})`, "success");
    } else {
      setApkFileName(file.name);
      setAppSize(calculatedSize);
      showToast(`APK fayl yuklandi: ${file.name} (${calculatedSize})`, "success");
    }
  };

  const handleIconUpload = async (e: React.ChangeEvent<HTMLInputElement>, isEdit: boolean) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const base64 = await fileToBase64(file);
        if (isEdit) {
          setEditIcon(base64);
        } else {
          setAppIcon(base64);
        }
        showToast("Ilova ikonasi yuklandi!", "success");
      } catch (err) {
        showToast("Rasm yuklashda xatolik", "error");
      }
    }
  };

  const handleScreenshotsUpload = async (e: React.ChangeEvent<HTMLInputElement>, isEdit: boolean) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      try {
        const base64List: string[] = [];
        for (let i = 0; i < files.length; i++) {
          const base64 = await fileToBase64(files[i]);
          base64List.push(base64);
        }
        if (isEdit) {
          setEditScreenshots(prev => [...prev, ...base64List]);
        } else {
          setAppScreenshots(prev => [...prev, ...base64List]);
        }
        showToast(`${files.length} ta skrinshot yuklandi!`, "success");
      } catch (err) {
        showToast("Yuklashda xatolik", "error");
      }
    }
  };

  // Create Submit
  const handleCreateAppSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!appName.trim() || !appShortDesc.trim() || !appLongDesc.trim() || !appVersion.trim()) {
      showToast("Iltimos, maydonlarni to'ldiring!", "error");
      return;
    }

    if (!apkFileName) {
      showToast("Ilovaning APK faylini kiritish shart! (Hajm shunga qarab avtomatik hisoblanadi)", "error");
      return;
    }

    if (!appIcon) {
      showToast("Ilova ikonasi kiritilishi shart!", "error");
      return;
    }

    onAddApp({
      name: appName.trim(),
      shortDescription: appShortDesc.trim(),
      description: appLongDesc.trim(),
      category: appCategory,
      version: appVersion.trim(),
      platform: appPlatform,
      fileSize: appSize,
      apkFileName: apkFileName,
      icon: appIcon,
      screenshots: appScreenshots,
      status: 'pending'
    });

    showToast(`"${appName}" kiritildi! Admin tasdig'idan so'ng do'konga qo'shiladi.`, "success");

    // Reset Add Form
    setAppName('');
    setAppShortDesc('');
    setAppLongDesc('');
    setAppCategory('Ilovalar');
    setAppVersion('1.0.0');
    setAppPlatform('Android');
    setAppSize('');
    setAppIcon('');
    setAppScreenshots([]);
    setApkFileName('');

    setActiveTab('ilovalarim');
  };

  // Launch edit app overlay
  const handleStartEditApp = (app: AppItem) => {
    setEditingApp(app);
    setEditName(app.name);
    setEditShortDesc(app.shortDescription);
    setEditLongDesc(app.description);
    setEditCategory(app.category);
    setEditVersion(app.version);
    setEditPlatform(app.platform);
    setEditSize(app.fileSize);
    setEditIcon(app.icon);
    setEditScreenshots(app.screenshots || []);
    setEditApkFileName(app.apkFileName || '');
  };

  // Edit Submit
  const handleEditAppSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingApp) return;

    if (!editName.trim() || !editShortDesc.trim() || !editLongDesc.trim() || !editVersion.trim()) {
      showToast("Majburiy maydonlarni to'ldiring!", "error");
      return;
    }

    onUpdateAppFields(editingApp.id, {
      name: editName.trim(),
      shortDescription: editShortDesc.trim(),
      description: editLongDesc.trim(),
      category: editCategory,
      version: editVersion.trim(),
      platform: editPlatform,
      fileSize: editSize,
      apkFileName: editApkFileName,
      icon: editIcon,
      screenshots: editScreenshots,
      status: 'pending' // Resets state to pending for safety when updated
    });

    showToast(`"${editName}" muvaffaqiyatli tahrirlandi va nazoratga yuborildi!`, "success");
    setEditingApp(null);
    setActiveTab('ilovalarim');
  };

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profCompanyName.trim() || !profFirstName.trim()) {
      showToast("Majburiy ma'lumotlarni to'ldiring!", "error");
      return;
    }
    onUpdateCreatorProfile(
      profCompanyName.trim(),
      profFirstName.trim(),
      profBio.trim(),
      profLogo || undefined,
      profPassword ? profPassword : undefined
    );
    setProfPassword('');
    showToast("Ma'lumotlar yangilandi!", "success");
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-gray-200 flex flex-col" id="creator-workspace-root">
      
      {/* 1. Navbar */}
      <nav className="bg-[#1c1c1e] border-b border-[#2c2c2e] sticky top-0 z-40 px-4 py-3 md:px-8 flex items-center justify-between" id="creator-navbar">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-white text-black rounded-lg flex items-center justify-center font-black">
            T
          </div>
          <div>
            <span className="text-sm font-bold text-white tracking-tight block">
              Tarmoq Creator Workspace
            </span>
            <span className="text-[9px] text-gray-400 block font-mono">{currentUser.companyName || 'Dasturchi'}</span>
          </div>
        </div>
        <button
          type="button"
          onClick={onLogout}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1c1c1e] hover:bg-[#2c2c2e] text-rose-400 font-bold text-xs rounded-xl cursor-pointer"
        >
          <LogOut size={13} />
          <span>Chiqish</span>
        </button>
      </nav>

      {/* 2. Sub Navigation Tabs (Hidden when in modal/active editing overlays) */}
      {!editingApp && (
        <div className="bg-[#1c1c1e] border-b border-[#2c2c2e]" id="creator-subnav">
          <div className="max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-start gap-4 overflow-x-auto">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={14} /> },
              { id: 'ilovalarim', label: 'Ilovalarim', icon: <Folder size={14} /> },
              { id: 'ilova-qoshish', label: 'Ilova Qo\'shish', icon: <PlusCircle size={14} /> },
              { id: 'analytics', label: 'Analitika', icon: <BarChart3 size={14} /> },
              { id: 'profil', label: 'Profil Ma\'lumotlari', icon: <Settings size={14} /> }
            ].map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 px-1 font-bold text-xs tracking-tight border-b-2 whitespace-nowrap cursor-pointer flex items-center gap-1.5 transition-all ${
                  activeTab === tab.id
                    ? 'border-white text-white'
                    : 'border-transparent text-gray-400 hover:text-white'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-8 py-8">
        
        {/* ==========================================
            EDIT MODE ACTIVE (TAHRIRLASH VA YANGILASH)
            ========================================== */}
        {editingApp ? (
          <div className="space-y-6" id="app-editor-container">
            <div className="flex items-center justify-between border-b border-zinc-900 pb-4">
              <div>
                <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Tahrirlash va Yangilash</span>
                <h2 className="text-xl font-black text-white">"{editingApp.name}" parametrlari</h2>
              </div>
              <button
                type="button"
                onClick={() => setEditingApp(null)}
                className="px-4 py-2 bg-zinc-900 text-xs font-bold text-white rounded-xl hover:bg-zinc-800"
              >
                Bekor qilish
              </button>
            </div>

            <form onSubmit={handleEditAppSubmit} className="bg-[#1c1c1e] border border-[#2c2c2e] rounded-3xl p-6 md:p-8 space-y-6" id="form-edit-app">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-gray-450 mb-1.5 uppercase tracking-wide">Ilova nomi</label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-450 mb-1.5 uppercase tracking-wide">Kategoriya</label>
                  <select
                    value={editCategory}
                    onChange={(e) => setEditCategory(e.target.value)}
                    className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none"
                  >
                    <option value="Ilovalar">Turmush Ilovalari</option>
                    <option value="O'yinlar">Qiziqarli O'yinlar</option>
                    <option value="Moliyaviy">Bank &amp; To'lov tizimi</option>
                    <option value="Ta'lim">Darslik va Ta'lim</option>
                    <option value="Ko'ngilochar">Ijtimoiy tarmoq &amp; Ko'ngilochar</option>
                  </select>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-gray-450 mb-1.5 uppercase tracking-wide">Katalog uchun qisqa tavsif</label>
                  <input
                    type="text"
                    required
                    maxLength={100}
                    value={editShortDesc}
                    onChange={(e) => setEditShortDesc(e.target.value)}
                    className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-gray-450 mb-1.5 uppercase tracking-wide">Batafsil tavsif</label>
                  <textarea
                    required
                    rows={4}
                    value={editLongDesc}
                    onChange={(e) => setEditLongDesc(e.target.value)}
                    className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none resize-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-450 mb-1.5 uppercase tracking-wide">Dastur versiyasi (Yangilanganda oshiring)</label>
                  <input
                    type="text"
                    required
                    value={editVersion}
                    onChange={(e) => setEditVersion(e.target.value)}
                    className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-450 mb-1.5 uppercase tracking-wide">Mos platforma</label>
                  <select
                    value={editPlatform}
                    onChange={(e) => setEditPlatform(e.target.value)}
                    className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none"
                  >
                    <option value="Android">Android tizimi</option>
                    <option value="iOS">iOS Apple</option>
                    <option value="Windows">Windows kompyuter</option>
                  </select>
                </div>

                {/* APK File Update section */}
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-white mb-2 uppercase tracking-wide">
                    APK Faylini Yangilash (.apk, yangilash uchun yuklang)
                  </label>
                  <div className="bg-[#0f0f0f] border border-[#2c2c2e] p-4 rounded-2xl flex flex-col sm:flex-row justify-between items-center gap-4">
                    <div className="space-y-1">
                      <input
                        id="edit-app-apk"
                        type="file"
                        accept=".apk"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) parseApkFile(file, true);
                        }}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => document.getElementById('edit-app-apk')?.click()}
                        className="px-4 py-2 bg-sky-950/20 hover:bg-sky-900 border border-sky-900/40 text-sky-400 font-bold text-xs rounded-xl cursor-pointer"
                      >
                        Yangi APK faylini yuklash
                      </button>
                      <p className="text-[10px] text-gray-500">
                        APK o'zgarganda dasturning fayl hajmi avtomatik hisoblab yangilanadi.
                      </p>
                    </div>

                    <div className="text-right">
                      <p className="text-xs text-gray-300 font-bold font-mono">
                        Hozirgi fayl: {editApkFileName || 'Noma\'lum'}
                      </p>
                      <p className="text-xs text-sky-400 font-bold font-mono mt-0.5">
                        Hajmi: {editSize || '0 MB'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Edit Icon */}
                <div>
                  <label className="block text-xs font-bold text-gray-450 mb-1.5 uppercase tracking-wide">Mavjud ikon tahriri</label>
                  <div className="flex items-center gap-3 bg-[#0f0f0f] p-3 rounded-xl border border-[#2c2c2e]">
                    <input
                      id="edit-app-icon-file"
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleIconUpload(e, true)}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => document.getElementById('edit-app-icon-file')?.click()}
                      className="px-3 py-1.5 bg-zinc-900 text-gray-300 font-bold text-xs rounded-lg border border-[#2c2c2e]"
                    >
                      Boshqa rasm yuklash
                    </button>
                    {editIcon && (
                      <img src={editIcon} alt="Icon" className="w-10 h-10 object-cover rounded-lg border border-[#2c2c2e]" />
                    )}
                  </div>
                </div>

                {/* Screenshots */}
                <div className="md:col-span-2 space-y-2">
                  <label className="block text-xs font-bold text-gray-455 mb-1 uppercase tracking-wide">Ishchi skrinshotlarni tahrirlash</label>
                  <div className="bg-[#0f0f0f] border border-[#2c2c2e] p-4 rounded-xl flex items-center gap-4">
                    <input
                      id="edit-app-shots-file"
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={(e) => handleScreenshotsUpload(e, true)}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => document.getElementById('edit-app-shots-file')?.click()}
                      className="px-4 py-2 bg-sky-950/20 border border-sky-900/30 text-sky-400 font-bold text-xs rounded-xl"
                    >
                      + Rasmlarni qo'shish
                    </button>
                    <span className="text-[10px] text-gray-500">Mavjudlarining o'ng burchagidagi "X" ni bosib o'chirishingiz mumkin.</span>
                  </div>

                  {editScreenshots.length > 0 && (
                    <div className="flex gap-4 overflow-x-auto pb-2 p-2 bg-[#0f0f0f] border border-dashed border-[#2c2c2e] rounded-xl">
                      {editScreenshots.map((shot, idx) => (
                        <div key={idx} className="relative shrink-0">
                          <img src={shot} alt="shot" className="h-24 rounded-lg object-contain border border-[#2c2c2e]" />
                          <button
                            type="button"
                            onClick={() => {
                              setEditScreenshots(prev => prev.filter((_, i) => i !== idx));
                              showToast("Skrinshot olib tashlandi", "info");
                            }}
                            className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-full text-[10px] flex items-center justify-center"
                          >
                            ✕
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 font-extrabold text-sm rounded-xl text-white shadow-lg cursor-pointer"
              >
                Muvaffaqiyatli Saqlash va Nazoratga Yuborish (Pending)
              </button>
            </form>
          </div>
        ) : (
          /* ====================================
              NORMAL TABS CONTROLLING
              ==================================== */
          <>
            {/* TAB: DASHBOARD */}
            {activeTab === 'dashboard' && (
              <div className="space-y-8" id="c-dashboard">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-black text-white">Xush kelibsiz, {currentUser.firstName}!</h2>
                    <p className="text-xs text-gray-400 mt-1">Siz yuklagan o'zbek mobil dasturlarining asosiy statistikasi.</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4" id="c-stat-cards">
                  <div className="bg-[#1c1c1e] border border-[#2c2c2e] p-5 rounded-2xl">
                    <p className="text-xs font-semibold text-gray-400">Jami ilovalar</p>
                    <p className="text-2xl font-black text-white mt-1.5">{totalAppsCount} ta</p>
                  </div>
                  <div className="bg-[#1c1c1e] border border-[#2c2c2e] p-5 rounded-2xl">
                    <p className="text-xs font-semibold text-gray-400">Tasdiqlangan</p>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="text-emerald-400"><CheckCircle size={18} /></span>
                      <p className="text-2xl font-black text-white">{approvedAppsCount} ta</p>
                    </div>
                  </div>
                  <div className="bg-[#1c1c1e] border border-[#2c2c2e] p-5 rounded-2xl">
                    <p className="text-xs font-semibold text-gray-400">Kutilmoqda (Pending)</p>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="text-amber-400"><Clock size={18} /></span>
                      <p className="text-2xl font-black text-white">{pendingAppsCount} ta</p>
                    </div>
                  </div>
                  <div className="bg-[#1c1c1e] border border-[#2c2c2e] p-5 rounded-2xl">
                    <p className="text-xs font-semibold text-gray-400">O'rnatishlar</p>
                    <p className="text-2xl font-black text-white mt-1.5">{formatDownloads(cumulativeDownloads)}</p>
                  </div>
                </div>

                <div className="bg-[#1c1c1e] border border-[#2c2c2e] rounded-3xl p-6 space-y-4">
                  <h3 className="text-sm font-extrabold text-white">Yaqinda kiritilgan ilovalar</h3>
                  {creatorApps.length === 0 ? (
                    <div className="text-center py-12 text-xs text-gray-500">
                      Sizda yuklangan ilovalar hozircha yo'q.
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-[#2c2c2e] text-gray-400 font-bold">
                            <th className="py-2.5 px-2">Ilova</th>
                            <th className="py-2.5 px-2">Kategoriya</th>
                            <th className="py-2.5 px-2">Hajmi</th>
                            <th className="py-2.5 px-2">Reyting</th>
                            <th className="py-2.5 px-2 text-right">Amallar</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-800/40">
                          {creatorApps.slice(0, 5).map(app => (
                            <tr key={app.id} className="hover:bg-zinc-900/40">
                              <td className="py-3 px-2 flex items-center gap-3">
                                <img src={app.icon} alt={app.name} className="w-8 h-8 rounded-lg object-cover" />
                                <div>
                                  <p className="font-bold text-white">{app.name}</p>
                                  <p className="text-[10px] text-zinc-500">V {app.version}</p>
                                </div>
                              </td>
                              <td className="py-3 px-2 text-zinc-400">{app.category}</td>
                              <td className="py-3 px-2 font-mono text-zinc-400">{app.fileSize}</td>
                              <td className="py-3 px-2 text-amber-500 font-bold font-mono">★ {app.ratingsCount === 0 ? '0' : (Math.round((app.ratingsSum / app.ratingsCount) * 10) / 10)}</td>
                              <td className="py-3 px-2 text-right space-x-2">
                                <button
                                  type="button"
                                  onClick={() => handleStartEditApp(app)}
                                  className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-850 rounded border border-zinc-800 text-stone-300 font-bold"
                                >
                                  Tahrirlash &amp; Yangilash
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB: ILOVALARIM */}
            {activeTab === 'ilovalarim' && (
              <div className="space-y-6" id="c-my-apps">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-black text-white">Yuklangan ilovalaringiz</h2>
                    <p className="text-xs text-gray-400 mt-1">Dasturlarni joriy tahriri va yangilash (yangi versiya/fayllarni biriktirish).</p>
                  </div>
                </div>

                {creatorApps.length === 0 ? (
                  <div className="text-center py-20 bg-[#1c1c1e] rounded-3xl border border-[#2c2c2e]">
                    <p className="text-sm text-gray-400">Ilovalar topilmadi.</p>
                  </div>
                ) : (
                  <div className="bg-[#1c1c1e] border border-[#2c2c2e] rounded-3xl p-6">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-[#2c2c2e] text-gray-400 font-bold">
                            <th className="py-3 px-2">Katalog</th>
                            <th className="py-3 px-2 font-bold text-gray-400">Versiya / Hajmi</th>
                            <th className="py-3 px-2 font-bold text-gray-400">Kategoriya</th>
                            <th className="py-3 px-2 font-bold text-gray-400">O'rnatilgan</th>
                            <th className="py-3 px-2 font-bold text-gray-400">Holati</th>
                            <th className="py-3 px-2 text-right">Amal yuklamalari</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-900">
                          {creatorApps.map(app => (
                            <tr key={app.id} className="hover:bg-zinc-900/20">
                              <td className="py-3 px-2 flex items-center gap-3">
                                <img src={app.icon} alt={app.name} className="w-10 h-10 object-cover rounded-xl" />
                                <div>
                                  <p className="font-extrabold text-sm text-white">{app.name}</p>
                                  <p className="text-[10px] text-zinc-500 font-mono">{app.apkFileName || 'no-file.apk'}</p>
                                </div>
                              </td>
                              <td className="py-3 px-2 font-mono">
                                <span className="bg-zinc-900 text-zinc-300 px-1.5 py-0.5 rounded text-[10px] font-bold">V {app.version}</span>
                                <span className="text-sky-400 font-bold block mt-1 text-[10px]">{app.fileSize}</span>
                              </td>
                              <td className="py-3 px-2 text-zinc-400 font-bold">{app.category}</td>
                              <td className="py-3 px-2 font-mono font-bold text-white">{formatDownloads(app.downloadsCount)}</td>
                              <td className="py-3 px-2">
                                {app.status === 'approved' ? (
                                  <span className="text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-900 font-bold px-2 py-0.5 rounded">Faol</span>
                                ) : app.status === 'pending' ? (
                                  <span className="text-xs text-amber-400 bg-amber-950/40 border border-amber-900 font-bold px-2 py-0.5 rounded animate-pulse">Pending</span>
                                ) : (
                                  <span className="text-xs text-rose-400 bg-rose-950/40 border border-rose-900 font-semibold px-2 py-0.5 rounded font-mono">Rad etilgan</span>
                                )}
                              </td>
                              <td className="py-3 px-2 text-right space-x-1 whitespace-nowrap">
                                <button
                                  type="button"
                                  onClick={() => handleStartEditApp(app)}
                                  className="px-2.5 py-1.5 bg-sky-950/30 border border-sky-850/40 text-sky-400 hover:bg-sky-900 text-[11px] font-extrabold rounded-lg cursor-pointer transition-colors"
                                >
                                  Tahrirlash &amp; Yangilash
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (window.confirm(`"${app.name}" ilovasini o'chirishni xohlaysizmi?`)) {
                                      onDeleteApp(app.id);
                                    }
                                  }}
                                  className="p-1.5 bg-rose-950/10 border border-rose-900/30 text-rose-400 hover:bg-rose-950 rounded-lg cursor-pointer"
                                  title="Ilovani butunlay o'chirish"
                                >
                                  <Trash2 size={13} />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB: ILOVA QO'SHISH */}
            {activeTab === 'ilova-qoshish' && (
              <div className="space-y-6" id="c-add-app">
                <div>
                  <h2 className="text-lg font-black text-white">Yangi yaratilgan ilovani qo'shish</h2>
                  <p className="text-xs text-gray-400 mt-1">Avval APK faylini yuklang. Tizim hajmini avtomatik hisoblab fiksatsiya qiladi.</p>
                </div>

                <form onSubmit={handleCreateAppSubmit} className="bg-[#1c1c1e] border border-[#2c2c2e] rounded-3xl p-6 md:p-8 space-y-6" id="form-create-app">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-bold text-gray-405 mb-1.5 uppercase tracking-wide">Ilova nomi</label>
                      <input
                        type="text"
                        required
                        placeholder="Masalan: Click Up"
                        value={appName}
                        onChange={(e) => setAppName(e.target.value)}
                        className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none focus:border-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-405 mb-1.5 uppercase tracking-wide">Kategoriya</label>
                      <select
                        value={appCategory}
                        onChange={(e) => setAppCategory(e.target.value)}
                        className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none"
                      >
                        <option value="Ilovalar">Turmush Ilovalari</option>
                        <option value="O'yinlar">Qiziqarli O'yinlar</option>
                        <option value="Moliyaviy">Bank &amp; To'lov tizimi</option>
                        <option value="Ta'lim">Darslik va Ta'lim</option>
                        <option value="Ko'ngilochar">Ijtimoiy tarmoq &amp; Ko'ngilochar</option>
                      </select>
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold text-gray-405 mb-1.5 uppercase tracking-wide">Katalog uchun qisqacha tavsif (Kengaytma emas)</label>
                      <input
                        type="text"
                        required
                        maxLength={100}
                        placeholder="Dasturingizni bitta qatorda sotuvchi va tushunarli ifodalang..."
                        value={appShortDesc}
                        onChange={(e) => setAppShortDesc(e.target.value)}
                        className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold text-gray-405 mb-1.5 uppercase tracking-wide">Batafsil tavsif</label>
                      <textarea
                        required
                        rows={4}
                        placeholder="Ushbu platformada foydalanuvchilar o'qiydigan batafsil yo'riqnoma..."
                        value={appLongDesc}
                        onChange={(e) => setAppLongDesc(e.target.value)}
                        className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none resize-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-405 mb-1.5 uppercase tracking-wide">Ilova boshlang'ich versiyasi</label>
                      <input
                        type="text"
                        required
                        placeholder="1.0.0"
                        value={appVersion}
                        onChange={(e) => setAppVersion(e.target.value)}
                        className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-405 mb-1.5 uppercase tracking-wide">Platforma</label>
                      <select
                        value={appPlatform}
                        onChange={(e) => setAppPlatform(e.target.value)}
                        className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none"
                      >
                        <option value="Android">Android tizimi</option>
                        <option value="iOS">iOS Apple</option>
                        <option value="Windows">Windows kompyuter</option>
                      </select>
                    </div>

                    {/* APK upload mandatory block */}
                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold text-white mb-2 uppercase tracking-wide">
                        Android APK Faylini yuklash (.apk - HAJM AVTOMATIK ANIQLANADI)
                      </label>
                      <div className="bg-[#0f0f0f] border border-[#2c2c2e] border-dashed p-6 rounded-2xl flex flex-col items-center justify-center text-center space-y-3">
                        <input
                          id="new-app-apk"
                          type="file"
                          accept=".apk"
                          required
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) parseApkFile(file, false);
                          }}
                          className="hidden"
                        />
                        <button
                          type="button"
                          onClick={() => document.getElementById('new-app-apk')?.click()}
                          className="px-5 py-3 bg-white text-black font-extrabold text-xs rounded-xl cursor-pointer shadow hover:bg-zinc-150 transition-colors"
                        >
                          📂 APK fayl tanlash (.apk)
                        </button>
                        
                        {apkFileName ? (
                          <div className="space-y-1">
                            <p className="text-xs text-emerald-400 font-bold font-mono">
                              ✓ Yuklangan fayl: {apkFileName}
                            </p>
                            <p className="text-xs text-sky-400 font-extrabold font-mono">
                              Avtomatik hisoblangan hajm: {appSize}
                            </p>
                          </div>
                        ) : (
                          <p className="text-xs text-zinc-500 font-semibold italic">
                            Dasturning xotira hajmi va ishlashini mustahkamlash uchun uning APK paketini yuklashingiz joiz.
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Displays size in a disabled clean status */}
                    <div>
                      <label className="block text-xs font-bold text-zinc-400 mb-1.5 uppercase tracking-wide">Hajmi (Avtomatik o'qiladi)</label>
                      <input
                        type="text"
                        disabled
                        placeholder="APK orqali aniqlanadi"
                        value={appSize}
                        className="w-full bg-zinc-950 border border-zinc-900 text-zinc-500 rounded-xl px-4 py-3 text-xs cursor-not-allowed font-mono font-bold"
                      />
                    </div>

                    {/* Icon */}
                    <div>
                      <label className="block text-xs font-bold text-gray-405 mb-1.5 uppercase tracking-wide">Logotip ikonasi (Upload)</label>
                      <div className="flex items-center gap-3 bg-[#0f0f0f] p-3.5 rounded-xl border border-[#2c2c2e]">
                        <input
                          id="new-app-icon-file"
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleIconUpload(e, false)}
                          className="hidden"
                        />
                        <button
                          type="button"
                          onClick={() => document.getElementById('new-app-icon-file')?.click()}
                          className="px-3 py-1.5 bg-zinc-900 text-gray-300 font-bold text-xs rounded-lg border border-[#2c2c2e]"
                        >
                          Logotip suratini tanlash
                        </button>
                        {appIcon && (
                          <img src={appIcon} alt="Icon preview" className="w-9 h-9 object-cover rounded" />
                        )}
                      </div>
                    </div>

                    {/* Screenshots */}
                    <div className="md:col-span-2 space-y-2">
                      <label className="block text-xs font-bold text-gray-405 mb-1 uppercase tracking-wide">Dastur ekran skrinshotlari (Gallereya)</label>
                      <div className="flex items-center gap-3 bg-[#0f0f0f] border border-[#2c2c2e] p-3.5 rounded-xl">
                        <input
                          id="new-app-shots-file"
                          type="file"
                          multiple
                          accept="image/*"
                          onChange={(e) => handleScreenshotsUpload(e, false)}
                          className="hidden"
                        />
                        <button
                          type="button"
                          onClick={() => document.getElementById('new-app-shots-file')?.click()}
                          className="px-4 py-2 bg-zinc-900 hover:bg-zinc-850 text-stone-200 border border-[#2c2c2e] text-xs font-bold rounded-lg cursor-pointer"
                        >
                          + Do'kon skrinshotlar qatorini yuklash
                        </button>
                      </div>

                      {appScreenshots.length > 0 && (
                        <div className="flex gap-4 overflow-x-auto pb-2 p-2 bg-[#0f0f0f] border border-dashed border-[#2c2c2e] rounded-xl">
                          {appScreenshots.map((shot, idx) => (
                            <div key={idx} className="relative shrink-0">
                              <img src={shot} alt="shot" className="h-24 rounded-lg object-contain border border-[#2c2c2e]" />
                              <button
                                type="button"
                                onClick={() => setAppScreenshots(prev => prev.filter((_, i) => i !== idx))}
                                className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-full text-[10px] flex items-center justify-center shadow"
                              >
                                ✕
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 bg-white text-black hover:bg-zinc-150 font-extrabold text-xs tracking-wider uppercase rounded-xl shadow-xl transition-all"
                  >
                    Yangi Ilovani Tasdiqlashga topshirish
                  </button>
                </form>
              </div>
            )}

            {/* TAB: ANALYTICS */}
            {activeTab === 'analytics' && (
              <div className="space-y-8" id="c-analytics">
                <div>
                  <h2 className="text-lg font-black text-white">Analitika &amp; Yuklamalar Hisoboti</h2>
                  <p className="text-xs text-gray-400 mt-1">Dasturlaringizning yuklash va reyting ulushi haqida to'liq tahrir.</p>
                </div>

                {creatorApps.length === 0 ? (
                  <div className="text-center py-12 text-xs text-gray-500">
                    Ma'lumotlar hozircha yo'q.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="c-graphics-grid">
                    <div className="bg-[#1c1c1e] border border-[#2c2c2e] p-6 rounded-3xl space-y-4">
                      <h3 className="text-xs font-bold text-white uppercase tracking-wider text-sky-450">Yuklamalar Bo'yicha</h3>
                      <div className="space-y-4">
                        {creatorApps.map(app => {
                          const sharePct = cumulativeDownloads > 0 
                            ? Math.round((app.downloadsCount / cumulativeDownloads) * 100) 
                            : 0;

                          return (
                            <div key={app.id} className="space-y-1">
                              <div className="flex justify-between text-xs font-semibold">
                                <span className="text-white">{app.name}</span>
                                <span className="text-stone-400 font-mono">{formatDownloads(app.downloadsCount)} ({sharePct}%)</span>
                              </div>
                              <div className="w-full bg-black h-2 rounded-full overflow-hidden">
                                <div className="bg-sky-550 h-2 rounded-full" style={{ width: `${Math.max(3, sharePct)}%` }} />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    <div className="bg-[#1c1c1e] border border-[#2c2c2e] p-6 rounded-3xl space-y-4">
                      <h3 className="text-xs font-bold text-white uppercase tracking-wider text-amber-500">Star Ratings averages</h3>
                      <div className="space-y-4">
                        {creatorApps.map(app => {
                          const avg = app.ratingsCount === 0 
                            ? 0 
                            : Math.round((app.ratingsSum / app.ratingsCount) * 10) / 10;
                          const starsPct = (avg / 5) * 100;

                          return (
                            <div key={app.id} className="space-y-1">
                              <div className="flex justify-between text-xs font-semibold">
                                <span className="text-white">{app.name}</span>
                                <span className="text-amber-400 font-mono">★ {avg}/5</span>
                              </div>
                              <div className="w-full bg-black h-2 rounded-full overflow-hidden">
                                <div className="bg-amber-400 h-2 rounded-full" style={{ width: `${starsPct}%` }} />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB: PROFIL */}
            {activeTab === 'profil' && (
              <div className="space-y-6" id="c-profile">
                <div>
                  <h2 className="text-lg font-black text-white">Yaratuvchi profili sozlari</h2>
                  <p className="text-xs text-gray-400 mt-1">Kompaniya tahriri va login parolini o'zgartirish.</p>
                </div>

                <form onSubmit={handleProfileSubmit} className="bg-[#1c1c1e] border border-[#2c2c2e] rounded-3xl p-6 md:p-8 space-y-5 max-w-xl" id="form-update-creator">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-400 mb-1">Kompaniya nomi</label>
                      <input
                        type="text"
                        required
                        value={profCompanyName}
                        onChange={(e) => setProfCompanyName(e.target.value)}
                        className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-400 mb-1">Dasturchi ismi</label>
                      <input
                        type="text"
                        required
                        value={profFirstName}
                        onChange={(e) => setProfFirstName(e.target.value)}
                        className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-gray-400 mb-1.5 font-sans">Kompaniya logosi</label>
                      <div className="flex items-center gap-4 bg-[#0f0f0f] p-3 rounded-xl border border-[#2c2c2e]">
                        <input
                          id="edit-company-logo-file"
                          type="file"
                          accept="image/*"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              try {
                                const b64 = await fileToBase64(file);
                                setProfLogo(b64);
                                showToast("Logo yangilandi!", "success");
                              } catch (_) {
                                showToast("Yuklashda xato", "error");
                              }
                            }
                          }}
                          className="hidden"
                        />
                        <button
                          type="button"
                          onClick={() => document.getElementById('edit-company-logo-file')?.click()}
                          className="px-3 py-1.5 bg-[#1c1c1e] text-gray-300 font-bold border border-[#2c2c2e] text-xs rounded-xl"
                        >
                          Rasm yuklash
                        </button>
                        {profLogo && (
                          <img src={profLogo} alt="Logo" className="w-10 h-10 rounded-xl object-cover border border-[#2c2c2e]" />
                        )}
                      </div>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-gray-400 mb-1">Kompaniya bio</label>
                      <textarea
                        rows={3}
                        value={profBio}
                        onChange={(e) => setProfBio(e.target.value)}
                        className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none resize-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-400 mb-1">Parol (Yangi, ixtiyoriy)</label>
                      <input
                        type="password"
                        placeholder="O'zgartirish uchun yozing"
                        value={profPassword}
                        onChange={(e) => setProfPassword(e.target.value)}
                        className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-4 py-3 text-xs focus:outline-none"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-white text-black font-extrabold text-xs rounded-xl"
                  >
                    Profilni yangilash
                  </button>
                </form>
              </div>
            )}
          </>
        )}

      </main>
    </div>
  );
};
