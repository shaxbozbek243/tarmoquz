import React, { useState } from 'react';
import { AppItem, User, Review, SystemMessage } from '../types';
import { RatingStars } from './RatingStars';
import { formatDownloads, getAverageRating } from '../utils';
import { ShoppingBag, Search, Download, User as UserIcon, LogOut, ArrowLeft, Star, Heart, Calendar, MessageSquare, Globe, ArrowUpRight, Bell } from 'lucide-react';

interface UserPanelViewProps {
  currentUser: User;
  onLogout: () => void;
  apps: AppItem[];
  onDownloadApp: (appId: string) => void;
  onAddReview: (appId: string, rating: number, text: string) => void;
  onUpdateUserProfile: (firstName: string, lastName: string, password?: string) => void;
  showToast: (text: string, type: 'success' | 'error' | 'info') => void;
  systemMessages: SystemMessage[];
}

export const UserPanelView: React.FC<UserPanelViewProps> = ({
  currentUser,
  onLogout,
  apps,
  onDownloadApp,
  onAddReview,
  onUpdateUserProfile,
  showToast,
  systemMessages
}) => {
  const [activeTab, setActiveTab] = useState<'bosh-sahifa' | 'oyinlar' | 'ilovalar' | 'yuklangan' | 'xabarlar'>('bosh-sahifa');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Barchasi');
  
  // App Detail states
  const [detailAppId, setDetailAppId] = useState<string | null>(null);
  
  // Custom Profile dropdown/management view toggle
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [editFirstName, setEditFirstName] = useState(currentUser.firstName || '');
  const [editLastName, setEditLastName] = useState(currentUser.lastName || '');
  const [editPassword, setEditPassword] = useState('');

  // Write Review interactive states
  const [showWriteReviewModal, setShowWriteReviewModal] = useState(false);
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewText, setNewReviewText] = useState('');
  
  // Review rating star filter state (null means all reviews)
  const [reviewStarsFilter, setReviewStarsFilter] = useState<number | null>(null);

  // Close views helper
  const handleBackToStore = () => {
    setDetailAppId(null);
    setReviewStarsFilter(null);
  };

  // Profile update submit
  const handleProfileUpdateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editFirstName.trim() || !editLastName.trim()) {
      showToast("Ism va familiyani kiritishingiz shart!", "error");
      return;
    }
    onUpdateUserProfile(editFirstName.trim(), editLastName.trim(), editPassword ? editPassword : undefined);
    setEditPassword('');
    setShowProfileModal(false);
  };

  // Review submit
  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!detailAppId) return;
    if (!newReviewText.trim()) {
      showToast("Sharh matnini kiritishingiz shart!", "error");
      return;
    }
    onAddReview(detailAppId, newReviewRating, newReviewText.trim());
    setNewReviewText('');
    setNewReviewRating(5);
    setShowWriteReviewModal(false);
  };

  // Collect specific categories for chips
  const customCategories = ['Barchasi', 'Ilovalar', "O'yinlar", 'Moliyaviy', 'Ta\'lim', 'Ko\'ngilochar'];

  // FILTERED APPROVED APPS FOR BROWSER
  const approvedApps = apps.filter(app => app.status === 'approved');

  // Search logic
  const searchedApps = approvedApps.filter(app => {
    const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          app.developer.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          app.shortDescription.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (activeTab === 'oyinlar') {
      return matchesSearch && app.category === "O'yinlar";
    }
    if (activeTab === 'ilovalar') {
      // Show anything belonging to categorizations that is not "O'yinlar" (or specific category filter if selected)
      const isNotGame = app.category !== "O'yinlar";
      const matchesCategory = selectedCategory === 'Barchasi' ? true : app.category === selectedCategory;
      return matchesSearch && isNotGame && matchesCategory;
    }
    if (activeTab === 'yuklangan') {
      return matchesSearch && currentUser.downloadedAppIds.includes(app.id);
    }
    return matchesSearch;
  });

  // Home view categorized modules
  // 1. TOP apps (for large banners)
  const topFeaturedApps = approvedApps.filter(app => app.isTop);
  // 2. Most Popular sorted by downloads count
  const popularApps = [...approvedApps].sort((a, b) => b.downloadsCount - a.downloadsCount);
  // 3. New apps simply reversed database order
  const newestApps = [...approvedApps].reverse();

  // Find currently open app detail
  const detailApp = approvedApps.find(app => app.id === detailAppId);

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-gray-200 gp-font flex flex-col" id="user-panel-wrapper">
      
      {/* 1. UPPER NAVBAR (Play Store Layout: Logo | Wide Search | Profile avatar) */}
      <nav className="bg-[#1c1c1e] border-b border-[#2c2c2e] sticky top-0 z-40 px-4 py-3 md:px-8 flex items-center justify-between" id="user-navbar">
        {/* Brand */}
        <div className="flex items-center gap-2.5 cursor-pointer shrink-0" onClick={handleBackToStore}>
          <div className="p-2 bg-[#0a84ff] rounded-xl flex items-center justify-center">
            <ShoppingBag size={20} className="text-white" />
          </div>
          <span className="text-xl font-bold text-white tracking-tight hidden sm:block">
            Tarmoq <span className="text-[#0a84ff]">Market</span>
          </span>
        </div>

        {/* Big Search Input (Center) */}
        {!detailApp && (
          <div className="flex-1 max-w-lg mx-4 md:max-w-2xl relative" id="search-bar-container">
            <Search className="absolute left-4 top-3 text-gray-500" size={18} />
            <input
              id="main-gp-search"
              type="text"
              placeholder="Ilovalar, o'yinlar yoki dasturchilarni qidiring..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#0f0f0f] border border-[#2c2c2e] focus:border-[#0a84ff] text-slate-100 rounded-full pl-11 pr-5 py-2.5 text-sm focus:outline-none transition-colors"
            />
          </div>
        )}

        {/* Profile Avatar Trigger & Dropdown info */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            id="avatar-btn"
            onClick={() => setShowProfileModal(true)}
            className="w-9 h-9 rounded-full bg-gradient-to-tr from-[#0a84ff] to-sky-400 font-bold text-sm text-white flex items-center justify-center border border-[#2c2c2e] hover:brightness-110 focus:outline-none cursor-pointer"
          >
            {currentUser.firstName ? currentUser.firstName.substring(0, 1).toUpperCase() : 'U'}
          </button>
        </div>
      </nav>

      {/* 2. SUB-NAV TABS ROW (Under Navbar) */}
      {!detailApp && (
        <div className="bg-[#1c1c1e] border-b border-[#2c2c2e] scrollbar-none" id="user-subnavigation">
          <div className="max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-start gap-6 md:gap-10">
            {[
              { id: 'bosh-sahifa', label: 'Bosh sahifa' },
              { id: 'oyinlar', label: "O'yinlar" },
              { id: 'ilovalar', label: 'Ilovalar' },
              { id: 'yuklangan', label: 'Yuklangan' },
              { id: 'xabarlar', label: `Xabarlar (${systemMessages.filter(m => m.recipientId === 'all' || m.recipientId === currentUser.id).length})` }
            ].map((tab) => (
              <button
                key={tab.id}
                id={`subtab-${tab.id}`}
                type="button"
                onClick={() => {
                  setActiveTab(tab.id as any);
                  setSearchQuery('');
                  setSelectedCategory('Barchasi');
                }}
                className={`py-3.5 font-bold text-sm border-b-2 whitespace-nowrap cursor-pointer transition-colors duration-200 block ${
                  activeTab === tab.id
                    ? 'border-[#0a84ff] text-[#0a84ff]'
                    : 'border-transparent text-gray-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 3. MAIN WORK AREA */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-8 py-6">
        
        {/* =======================================================
            APP DETAIL FULL PAGE USLUBLARI
            ======================================================= */}
        {detailApp ? (
          <div className="space-y-8" id="app-detail-screen">
            {/* Back Button */}
            <button
              type="button"
              id="detail-back-btn"
              onClick={handleBackToStore}
              className="flex items-center gap-2 text-sm text-gray-400 hover:text-white cursor-pointer"
            >
              <ArrowLeft size={18} />
              <span>Orqaga qaytish</span>
            </button>

            {/* Core Header info (96px large rounded icon, Developer name, ratings, downloads) */}
            <div className="bg-[#1c1c1e] p-6 md:p-8 rounded-3xl border border-[#2c2c2e]" id="detail-header-card">
              <div className="flex flex-col md:flex-row gap-6 items-start justify-between">
                
                <div className="flex gap-6 items-start">
                  <img
                    src={detailApp.icon}
                    alt={`${detailApp.name} grand icon`}
                    className="w-24 h-24 rounded-[22px] border border-[#2c2c2e] shadow-xl object-cover shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <span className="px-3 py-1 bg-[#0a84ff]/10 text-[#0a84ff] text-[10px] font-bold rounded-full uppercase tracking-wider">
                      {detailApp.category}
                    </span>
                    <h2 className="text-2xl md:text-3xl font-black text-white mt-1.5 leading-none">
                      {detailApp.name}
                    </h2>
                    <p className="text-sm text-gray-400 mt-1 font-semibold">
                      {detailApp.developer}
                    </p>
                    <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500 font-medium">
                      <span>Platforma: <span className="text-gray-300 font-semibold">{detailApp.platform}</span></span>
                      <span>•</span>
                      <span>Hajmi: <span className="text-gray-300 font-semibold">{detailApp.fileSize}</span></span>
                      <span>•</span>
                      <span>Versiya: <span className="text-gray-300 font-semibold">{detailApp.version}</span></span>
                    </div>
                  </div>
                </div>

                {/* Big Green Play Store style Download button */}
                <div className="w-full md:w-auto shrink-0 flex flex-col sm:flex-row md:flex-col gap-3">
                  <button
                    type="button"
                    id={`btn-download-${detailApp.id}`}
                    onClick={() => onDownloadApp(detailApp.id)}
                    className="w-full md:w-48 py-3 px-6 bg-[#00875a] hover:bg-emerald-700 text-white font-bold text-sm rounded-xl cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/20"
                  >
                    <Download size={18} />
                    <span>{currentUser.downloadedAppIds.includes(detailApp.id) ? "Qayta yuklash" : "Yuklab olish"}</span>
                  </button>
                  {currentUser.downloadedAppIds.includes(detailApp.id) && (
                    <div className="text-center md:text-left px-3 py-1 bg-emerald-950/20 border border-emerald-500/20 rounded-lg">
                      <p className="text-[11px] text-emerald-400 font-semibold">✓ Qurilmangizga o'rnatilgan</p>
                    </div>
                  )}
                </div>

              </div>

              {/* Stats Bar Component */}
              <div className="grid grid-cols-3 gap-1 divide-x divide-[#2c2c2e] border-t border-[#2c2c2e] mt-6 pt-5" id="detail-stats-bar">
                <div className="text-center">
                  <p className="text-lg font-extrabold text-white font-mono flex items-center justify-center gap-1">
                    <span>{getAverageRating(detailApp) > 0 ? getAverageRating(detailApp) : '0.0'}</span>
                    <span className="text-amber-400 text-sm">★</span>
                  </p>
                  <p className="text-[11px] text-gray-500 font-medium mt-0.5">{detailApp.ratingsCount} ta baholash</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-extrabold text-white font-mono">
                    {formatDownloads(detailApp.downloadsCount)}
                  </p>
                  <p className="text-[11px] text-gray-500 font-medium mt-0.5">Yuklanishlar</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-extrabold text-white flex items-center justify-center">
                    Barchaga
                  </p>
                  <p className="text-[11px] text-gray-500 font-medium mt-0.5">3+ Yosh chegarasi</p>
                </div>
              </div>
            </div>

            {/* horizontal Screenshots Carousel */}
            <div className="space-y-3" id="app-detail-screenshots">
              <h3 className="text-base font-bold text-white">Xizmat darchalari (Skrinshotlar)</h3>
              <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-none" id="screenshots-container">
                {detailApp.screenshots && detailApp.screenshots.length > 0 ? (
                  detailApp.screenshots.map((shot, i) => (
                    <img
                      key={i}
                      src={shot}
                      alt={`${detailApp.name} screenshot ${i + 1}`}
                      className="max-h-52 rounded-2xl border border-[#2c2c2e] bg-[#1c1c1e] shrink-0"
                    />
                  ))
                ) : (
                  <div className="py-10 text-center w-full bg-[#1c1c1e] rounded-xl border border-[#2c2c2e]">
                    <p className="text-xs text-gray-500">Ushbu ilova uchun skrinshotlar kiritilmagan.</p>
                  </div>
                )}
              </div>
            </div>

            {/* Description Text block (to'liq matn) */}
            <div className="bg-[#1c1c1e] p-6 rounded-3xl border border-[#2c2c2e] space-y-3" id="app-detail-description">
              <h3 className="text-base font-bold text-white">Ilova haqida ma'lumot</h3>
              <p className="text-sm text-gray-300 leading-relaxed whitespace-pre-wrap">
                {detailApp.description}
              </p>
            </div>

            {/* App Reviews rating filters + Lists */}
            <div className="bg-[#1c1c1e] p-6 rounded-3xl border border-[#2c2c2e] space-y-6" id="app-detail-reviews-area">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#2c2c2e] pb-5">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <MessageSquare size={18} className="text-[#0a84ff]" />
                    <span>Foydalanuvchilar fikri</span>
                  </h3>
                  <p className="text-xs text-gray-500 mt-1">Ushbu dastur haqida boshqa ishtirokchilar tomonidan qoldirilgan baholar.</p>
                </div>
                
                <button
                  type="button"
                  id="btn-trigger-write-review"
                  onClick={() => setShowWriteReviewModal(true)}
                  className="py-2.5 px-4 bg-[#0a84ff]/10 hover:bg-[#0a84ff]/20 text-[#0a84ff] font-bold text-xs rounded-xl cursor-pointer"
                >
                  ✓ Sharh qoldirish
                </button>
              </div>

              {/* Star Rating Filters Row */}
              <div className="flex flex-wrap items-center gap-2" id="reviews-filters">
                <span className="text-xs text-gray-500 font-semibold">Yulduz bo'yicha saralash:</span>
                <button
                  type="button"
                  id="filter-star-all"
                  onClick={() => setReviewStarsFilter(null)}
                  className={`px-3 py-1 bg-transparent rounded-full border text-xs font-semibold ${
                    reviewStarsFilter === null
                      ? 'border-[#0a84ff] text-[#0a84ff]'
                      : 'border-[#2c2c2e] text-gray-400 hover:text-white'
                  }`}
                >
                  Barchasi
                </button>
                {[5, 4, 3, 2, 1].map(star => (
                  <button
                    key={star}
                    id={`filter-star-${star}`}
                    type="button"
                    onClick={() => setReviewStarsFilter(star)}
                    className={`px-3 py-1 rounded-full border text-xs font-semibold flex items-center gap-1 ${
                      reviewStarsFilter === star
                        ? 'border-[#0a84ff] text-[#0a84ff]'
                        : 'border-[#2c2c2e] text-gray-400 hover:text-white'
                    }`}
                  >
                    <span>{star}</span>
                    <span className="text-amber-400 font-sans">★</span>
                  </button>
                ))}
              </div>

              {/* Reviews matching filter list */}
              <div className="space-y-4" id="reviews-list-container">
                {(() => {
                  const filteredReviews = detailApp.reviews.filter(rev => {
                    if (reviewStarsFilter === null) return true;
                    return rev.rating === reviewStarsFilter;
                  });

                  if (filteredReviews.length === 0) {
                    return (
                      <div className="text-center py-8 text-xs text-gray-500">
                        {reviewStarsFilter === null 
                          ? 'Ilova uchun sharhlar hozircha kiritilmagan. Birinchi bo\'lib o\'z fikringizni yozib qoldiring!' 
                          : `${reviewStarsFilter} yulduzli sharhlar topilmadi.`}
                      </div>
                    );
                  }

                  return filteredReviews.map(rev => (
                    <div key={rev.id} className="p-4 bg-[#0f0f0f] rounded-2xl border border-[#2c2c2e] space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 bg-gray-800 rounded-full flex items-center justify-center text-xs font-bold text-white">
                            {rev.userName.substring(0, 1).toUpperCase()}
                          </div>
                          <div>
                            <p className="text-xs font-bold text-white">{rev.userName}</p>
                            <p className="text-[10px] text-gray-500">{rev.date}</p>
                          </div>
                        </div>
                        <RatingStars rating={rev.rating} size={12} />
                      </div>
                      <p className="text-xs text-gray-300 pl-9 leading-relaxed">
                        {rev.text}
                      </p>
                    </div>
                  ));
                })()}
              </div>

            </div>
          </div>
        ) : (
          /* =======================================================
              NORMAL APP BROWSER SYSTEM BY SELECTED SUB-TAB
              ======================================================= */
          <div className="space-y-8" id="store-main-view">
            
            {/* SEARCHING STATS INDICATOR */}
            {searchQuery && (
              <div className="p-4 bg-[#1c1c1e] rounded-xl border border-[#2c2c2e] flex justify-between items-center text-xs">
                <div className="text-gray-300">
                  Qidiruv natijasi: <span className="text-[#0a84ff] font-bold">"{searchQuery}"</span>
                </div>
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="text-[11px] font-bold text-amber-500 hover:underline"
                >
                  Tozalash
                </button>
              </div>
            )}

            {activeTab === 'bosh-sahifa' && !searchQuery ? (
              /* TAB: BOSH SAHIFA */
              <div className="space-y-10" id="tab-home-content">
                
                {/* 1. Tavsiya etilgan (Featured large banner cards based on admin checking isTop: true) */}
                <section className="space-y-4" id="home-tops">
                  <h3 className="text-lg font-bold text-white">Tavsiya etilgan ilovalar</h3>
                  {topFeaturedApps.length === 0 ? (
                    <div className="p-8 text-center bg-[#1c1c1e] rounded-2xl border border-[#2c2c2e]">
                      <p className="text-xs text-gray-500">Hozirda tanlangan tahririyat tavsiyalari mavjud emas. Admin panelda birorta ilovani TOP guruhiga qo'shing.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="top-featured-list">
                      {topFeaturedApps.map(app => {
                        const score = getAverageRating(app);
                        return (
                          <div
                            key={app.id}
                            id={`top-card-${app.id}`}
                            onClick={() => setDetailAppId(app.id)}
                            className="bg-gradient-to-br from-[#1c1c1e] to-sky-950/20 hover:border-blue-500/30 border border-[#2c2c2e] p-6 rounded-3xl relative overflow-hidden flex flex-col justify-between h-52 cursor-pointer transition-colors"
                          >
                            <div className="absolute top-4 right-4 bg-[#0a84ff] text-white text-[9px] font-black tracking-wider uppercase px-2 py-1 rounded">
                              Tavsiya
                            </div>
                            <div className="flex gap-4 items-start">
                              <img
                                src={app.icon}
                                alt={`${app.name} icon`}
                                className="w-16 h-16 rounded-[22px] border border-[#2c2c2e] object-cover shrink-0"
                                referrerPolicy="no-referrer"
                              />
                              <div className="min-w-0 pr-12">
                                <h4 className="text-lg font-black text-white tracking-tight truncate">{app.name}</h4>
                                <p className="text-xs text-[#0a84ff] font-bold mt-0.5">{app.developer}</p>
                                <p className="text-xs text-gray-400 mt-1.5 line-clamp-2 leading-relaxed">{app.shortDescription}</p>
                              </div>
                            </div>
                            <div className="pt-4 border-t border-[#2c2c2e] flex items-center justify-between text-xs text-gray-400">
                              <span className="flex items-center gap-1">★ <span className="font-bold text-white">{score > 0 ? score : 'Yo\'q'}</span> ({app.ratingsCount} ta ovoz)</span>
                              <span className="font-mono text-emerald-400 font-bold">{formatDownloads(app.downloadsCount)} yuklamalar</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </section>

                {/* 2. Eng Mashhur (Horizontal scrolling small cards in row) */}
                <section className="space-y-4" id="home-popular">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-white">Eng ommabop yuklamalar</h3>
                    <span className="text-xs font-semibold text-gray-500">Eng ko'p ishlatilgan</span>
                  </div>
                  <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-none" id="popular-horizontal-lane">
                    {popularApps.slice(0, 6).map(app => {
                      const score = getAverageRating(app);
                      return (
                        <div
                          key={app.id}
                          id={`popular-card-${app.id}`}
                          onClick={() => setDetailAppId(app.id)}
                          className="w-44 shrink-0 bg-[#1c1c1e] hover:bg-[#1c1c1e]/80 border border-[#2c2c2e] p-4 rounded-3xl flex flex-col justify-between h-44 cursor-pointer"
                        >
                          <div className="flex gap-3 items-center">
                            <img
                              src={app.icon}
                              alt={`${app.name} icon`}
                              className="w-11 h-11 rounded-xl border border-[#2c2c2e] object-cover shrink-0"
                              referrerPolicy="no-referrer"
                            />
                            <div className="min-w-0">
                              <h4 className="text-xs font-bold text-white truncate leading-tight">{app.name}</h4>
                              <p className="text-[10px] text-gray-500 truncate mt-0.5">{app.developer}</p>
                            </div>
                          </div>
                          <p className="text-[11px] text-gray-400 line-clamp-2 leading-tight mt-1">
                            {app.shortDescription}
                          </p>
                          <div className="border-t border-[#2c2c2e] pt-2 mt-2 flex items-center justify-between text-[11px]">
                            <span className="text-amber-400">★ {score > 0 ? score : 'Yo\'q'}</span>
                            <span className="font-mono text-gray-400">{formatDownloads(app.downloadsCount)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </section>

                {/* 3. Yangi (Standard Grid Layout) */}
                <section className="space-y-4" id="home-newest">
                  <h3 className="text-lg font-bold text-white">Yangi qo'shilgan ilovalar</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5" id="newest-grid">
                    {newestApps.slice(0, 8).map(app => {
                      const score = getAverageRating(app);
                      return (
                        <div
                          key={app.id}
                          id={`newest-card-${app.id}`}
                          onClick={() => setDetailAppId(app.id)}
                          className="bg-[#1c1c1e] hover:border-gray-700/60 border border-[#2c2c2e] p-4 rounded-3xl flex flex-col justify-between cursor-pointer"
                        >
                          <div className="flex gap-4 items-start">
                            <img
                              src={app.icon}
                              alt={`${app.name} icon`}
                              className="w-12 h-12 rounded-2xl border border-[#2c2c2e] object-cover shrink-0"
                              referrerPolicy="no-referrer"
                            />
                            <div className="min-w-0">
                              <span className="text-[9px] font-mono tracking-widest text-[#0a84ff] uppercase font-bold">{app.category}</span>
                              <h4 className="text-sm font-bold text-white truncate mt-0.5">{app.name}</h4>
                              <p className="text-xs text-gray-400 truncate mt-0.5">{app.developer}</p>
                            </div>
                          </div>
                          <div className="mt-4 pt-3 border-t border-[#2c2c2e] flex items-center justify-between text-[11px] text-gray-500 font-semibold">
                            <span>★ {score > 0 ? score : 'Yo\'q'}</span>
                            <span>{formatDownloads(app.downloadsCount)} marta</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </section>
              </div>
            ) : activeTab === 'oyinlar' ? (
              /* TAB: O'YINLAR */
              <div className="space-y-6" id="tab-games-content">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-white">Eng sara o'yinlar</h3>
                    <p className="text-xs text-gray-500 mt-1">O'zbek o'yin olamidagi qiziqarli lahzalar, viktorinalar va jangovar strategiyalar.</p>
                  </div>
                </div>

                {searchedApps.length === 0 ? (
                  <div className="text-center py-12 bg-[#1c1c1e] rounded-xl border border-[#2c2c2e] text-gray-500 text-xs">
                    Hech qanday o'yinlar munosib hisoblanmadi.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5" id="games-app-grid">
                    {searchedApps.map(app => {
                      const score = getAverageRating(app);
                      return (
                        <div
                          key={app.id}
                          id={`game-card-${app.id}`}
                          onClick={() => setDetailAppId(app.id)}
                          className="bg-[#1c1c1e] border border-[#2c2c2e] p-4 rounded-3xl cursor-pointer hover:border-gray-700 flex flex-col justify-between"
                        >
                          <div className="flex gap-4 items-start">
                            <img
                              src={app.icon}
                              alt={`${app.name} icon`}
                              className="w-14 h-14 rounded-2xl border border-[#2c2c2e] object-cover shrink-0"
                              referrerPolicy="no-referrer"
                            />
                            <div className="min-w-0">
                              <h4 className="text-sm font-bold text-white truncate leading-tight">{app.name}</h4>
                              <p className="text-xs text-gray-400 truncate mt-1">{app.developer}</p>
                            </div>
                          </div>
                          <div className="mt-4 pt-3 border-t border-[#2c2c2e] flex items-center justify-between text-[11px] text-gray-400 font-semibold">
                            <span>★ {score > 0 ? score : 'Ovozsiz'}</span>
                            <span>{formatDownloads(app.downloadsCount)} yuklangan</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ) : activeTab === 'ilovalar' ? (
              /* TAB: ILOVALAR */
              <div className="space-y-6" id="tab-applications-content">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h3 className="text-xl font-bold text-white">Barcha ilovalar turkumi</h3>
                    <p className="text-xs text-gray-500 mt-1">Har qanday qulayliklar uchun foydali milliy ilovalar to'plami.</p>
                  </div>
                  {/* Category Chips line inside games/apps */}
                  <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none" id="apps-chips">
                    {customCategories.filter(cat => cat !== "O'yinlar").map(cat => (
                      <button
                        key={cat}
                        id={`app-chip-${cat.replace(/\s+/g, '-').toLowerCase()}`}
                        type="button"
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-3 py-1.5 rounded-full text-[11px] font-bold cursor-pointer whitespace-nowrap transition-colors duration-200 ${
                          selectedCategory === cat
                            ? 'bg-[#0a84ff] text-white'
                            : 'bg-[#1c1c1e] text-gray-400 border border-[#2c2c2e]'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {searchedApps.length === 0 ? (
                  <div className="text-center py-12 bg-[#1c1c1e] rounded-xl border border-[#2c2c2e] text-gray-500 text-xs text-center">
                    Ushbu turkum bo'yicha ilovalar topilmadi.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5" id="applications-app-grid">
                    {searchedApps.map(app => {
                      const score = getAverageRating(app);
                      return (
                        <div
                          key={app.id}
                          id={`app-item-card-${app.id}`}
                          onClick={() => setDetailAppId(app.id)}
                          className="bg-[#1c1c1e] border border-[#2c2c2e] p-4 rounded-3xl cursor-pointer hover:border-gray-700 flex flex-col justify-between"
                        >
                          <div className="flex gap-4 items-start">
                            <img
                              src={app.icon}
                              alt={`${app.name} icon`}
                              className="w-14 h-14 rounded-2xl border border-[#2c2c2e] object-cover shrink-0"
                              referrerPolicy="no-referrer"
                            />
                            <div className="min-w-0">
                              <span className="text-[9px] font-bold text-gray-500 uppercase">{app.category}</span>
                              <h4 className="text-sm font-bold text-white truncate mt-0.5 leading-tight">{app.name}</h4>
                              <p className="text-xs text-gray-400 truncate mt-1">{app.developer}</p>
                            </div>
                          </div>
                          <div className="mt-4 pt-3 border-t border-[#2c2c2e] flex items-center justify-between text-[11px] text-gray-400 font-semibold">
                            <span>★ {score > 0 ? score : 'Ovozsiz'}</span>
                            <span>{formatDownloads(app.downloadsCount)} yuklamalar</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ) : activeTab === 'yuklangan' ? (
              /* TAB: YUKLANGAN */
              <div className="space-y-6" id="tab-installed-content">
                <div>
                  <h3 className="text-xl font-bold text-white">Siz yuklab olgan ilovalar</h3>
                  <p className="text-xs text-gray-500 mt-1">Ushbu qurilmadagi o'rnatilgan ilovalarning to'liq ro'yxati.</p>
                </div>

                {searchedApps.length === 0 ? (
                  <div className="text-center py-16 bg-[#1c1c1e] rounded-2xl border border-[#2c2c2e]">
                    <p className="text-sm text-gray-400">Sizda yuklab olingan ilovalar mavjud emas. Kerakli ilovani topib yuklab oling!</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5" id="installed-grid">
                    {searchedApps.map(app => (
                      <div
                        key={app.id}
                        id={`installed-item-${app.id}`}
                        className="bg-[#1c1c1e] border border-[#2c2c2e] p-5 rounded-3xl flex gap-4 items-center justify-between"
                      >
                        <div className="flex gap-4 items-center cursor-pointer" onClick={() => setDetailAppId(app.id)}>
                          <img
                            src={app.icon}
                            alt={`${app.name} logo`}
                            className="w-12 h-12 rounded-2xl border border-[#2c2c2e] object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <div className="min-w-0">
                            <h4 className="text-sm font-bold text-white truncate">{app.name}</h4>
                            <p className="text-xs text-gray-400 truncate mt-0.5">{app.developer}</p>
                            <span className="text-[9px] px-1.5 py-0.5 bg-emerald-950 text-emerald-300 font-bold rounded mt-1.5 inline-block">Tasdiqlangan</span>
                          </div>
                        </div>

                        <button
                          type="button"
                          id={`btn-open-app-${app.id}`}
                          onClick={() => showToast(`"${app.name}" moduli muvaffaqiyatli ishga tushirildi!`, "success")}
                          className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 font-bold text-xs rounded-xl text-white cursor-pointer"
                        >
                          Ochish
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              /* TAB: XABARLAR */
              <div className="space-y-6" id="tab-messages-content">
                <div>
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <Bell size={20} className="text-[#0a84ff]" />
                    <span>Administrator Xabarlari va E'lonlari</span>
                  </h3>
                  <p className="text-xs text-gray-500 mt-1">Sizga va umumiy hamjamiyatga yuborilgan rasmiy tizim yangiliklari.</p>
                </div>

                {systemMessages.filter(msg => msg.recipientId === 'all' || msg.recipientId === currentUser.id).length === 0 ? (
                  <div className="text-center py-16 bg-[#1c1c1e] rounded-2xl border border-[#2c2c2e]">
                    <p className="text-sm text-gray-400">Sizda hozircha kelgan xabarlar mavjud emas.</p>
                  </div>
                ) : (
                  <div className="space-y-4 max-w-3xl" id="messages-list-wrapper">
                    {systemMessages
                      .filter(msg => msg.recipientId === 'all' || msg.recipientId === currentUser.id)
                      .map(msg => (
                        <div key={msg.id} className="bg-[#1c1c1e] border-l-4 border-[#0a84ff] border border-y-[#2c2c2e] border-r-[#2c2c2e] p-5 rounded-2xl space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] uppercase font-bold text-[#0a84ff] tracking-widest">{msg.recipientId === 'all' ? '📢 Hamma uchun' : '🔒 Shaxsiy ma\'lumot'}</span>
                            <span className="text-[10px] text-gray-500 font-mono">{msg.date}</span>
                          </div>
                          <h4 className="text-sm font-extrabold text-white">{msg.title}</h4>
                          <p className="text-xs text-gray-300 leading-relaxed font-sans mt-2">{msg.content}</p>
                          <div className="pt-2 flex items-center gap-1.5 text-[9px] text-gray-400 font-mono">
                            <span>Yuboruvchi:</span>
                            <span className="font-bold text-gray-300">{msg.sender}</span>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            )}

          </div>
        )}

      </main>

      {/* =======================================================
          MODAL: WRITE OR EDIT USER PROFILE DATA (WITH PASSWORD EDIT)
          ======================================================= */}
      {showProfileModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" id="profile-edit-modal">
          <div className="bg-[#1c1c1e] border border-[#2c2c2e] rounded-3xl max-w-sm w-full p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-[#2c2c2e] pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <UserIcon size={18} className="text-[#0a84ff]" />
                <span>Profil Ma'lumotlari</span>
              </h3>
              <button
                type="button"
                id="close-profile-modal-x"
                onClick={() => setShowProfileModal(false)}
                className="text-gray-500 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 font-mono text-xs bg-black/30 p-4 rounded-2xl text-left border border-[#2c2c2e]">
              <div className="flex justify-between">
                <span className="text-gray-400">Pochta manzili:</span>
                <span className="text-white font-bold">{currentUser.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Rol:</span>
                <span className="text-blue-400 uppercase font-black">{currentUser.role}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Yuklangan dasturlar:</span>
                <span className="text-emerald-400 font-bold">{currentUser.downloadedAppIds.length} ta xizmat</span>
              </div>
            </div>

            <form onSubmit={handleProfileUpdateSubmit} className="space-y-4" id="form-edit-uprofile">
              <div>
                <label className="block text-[11px] font-bold text-gray-405 mb-1 uppercase tracking-wide">Ism</label>
                <input
                  id="profile-f-name"
                  type="text"
                  required
                  value={editFirstName}
                  onChange={(e) => setEditFirstName(e.target.value)}
                  className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#0a84ff]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-405 mb-1 uppercase tracking-wide">Familiya</label>
                <input
                  id="profile-l-name"
                  type="text"
                  required
                  value={editLastName}
                  onChange={(e) => setEditLastName(e.target.value)}
                  className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#0a84ff]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-405 mb-1 uppercase tracking-wide">Yangi Parol (ixtiyoriy)</label>
                <input
                  id="profile-password"
                  type="password"
                  placeholder="O'zgartirmaslik uchun bo'sh qoldiring"
                  value={editPassword}
                  onChange={(e) => setEditPassword(e.target.value)}
                  className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#0a84ff]"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  id="btn-logout"
                  onClick={onLogout}
                  className="flex-1 py-2.5 bg-rose-950/40 hover:bg-rose-900 border border-rose-600/30 text-rose-300 font-bold text-xs rounded-xl cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <LogOut size={14} />
                  <span>Chiqish</span>
                </button>
                <button
                  type="submit"
                  id="btn-save-uprofile"
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 font-bold text-xs text-white rounded-xl cursor-pointer"
                >
                  Saqlash
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =======================================================
          MODAL: WRITE REVIEW (RATING + TEXT COMMENTS)
          ======================================================= */}
      {showWriteReviewModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" id="review-write-modal">
          <div className="bg-[#1c1c1e] border border-[#2c2c2e] rounded-3xl max-w-sm w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#2c2c2e] pb-3">
              <h3 className="text-base font-bold text-white">Baholash va Sharh Yozish</h3>
              <button
                type="button"
                id="close-review-modal-x"
                onClick={() => setShowWriteReviewModal(false)}
                className="text-gray-500 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleReviewSubmit} className="space-y-4" id="form-add-review">
              <div>
                <label className="block text-xs text-gray-400 mb-1.5 font-bold uppercase">Xizmatga bahoingiz</label>
                <RatingStars
                  rating={newReviewRating}
                  interactive={true}
                  onChange={(score) => setNewReviewRating(score)}
                  size={24}
                />
              </div>

              <div>
                <label className="block text-xs text-gray-400 mb-1.5 font-bold uppercase">Sharh matni</label>
                <textarea
                  id="review-text-textarea"
                  required
                  rows={4}
                  placeholder="Ilova sizga qanchalik ma'qul keldi? To'lovlar, tezkorlik va kamchiliklar haqida batafsil yozishingiz mumkin..."
                  value={newReviewText}
                  onChange={(e) => setNewReviewText(e.target.value)}
                  className="w-full bg-[#0f0f0f] border border-[#2c2c2e] text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#0f0f0f] resize-none"
                />
              </div>

              <button
                type="submit"
                id="btn-save-review"
                className="w-full py-2.5 bg-[#0a84ff] hover:bg-blue-600 font-bold text-xs text-white rounded-xl cursor-pointer"
              >
                Sharhni nashr etish
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
